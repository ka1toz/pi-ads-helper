/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.ads.sdk;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.ads.sdk";
  public static final String BUILD_TYPE = "release";
}
