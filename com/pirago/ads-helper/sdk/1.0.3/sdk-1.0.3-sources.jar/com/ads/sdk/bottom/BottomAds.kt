package com.ads.sdk.bottom

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import com.ads.sdk.AdsSdk
import com.ads.sdk.BottomAdConfig
import com.ads.sdk.NativeCollapConfig
import com.ads.sdk.NativeTemplate
import com.ads.sdk.callback.AdCallback
import com.ads.sdk.callback.AdError
import com.ads.sdk.internal.SdkLog
import com.ads.sdk.nativead.NativeCollapPolicy

class BottomAds internal constructor() {

    /**
     * DIY Home bottom slot:
     * - `collapsible=false`: Native Small **or** Banner (static).
     * - `collapsible=true` and (`showNativeSmall` or `reloadSec>0`): native
     *   collapsible that collapses to Small or Banner, then optionally re-expands.
     * - otherwise: plain Banner.
     */
    fun load(
        activity: Activity,
        container: ViewGroup,
        config: BottomAdConfig,
        shimmer: View? = null,
        placement: String? = null,
        callback: AdCallback? = null,
    ) {
        AdsSdk.banner.destroy(container)
        AdsSdk.native.destroy(container)
        AdsSdk.mrec.destroy(container)
        if (AdsSdk.isMax) {
            SdkLog.w("Bottom native skipped: MAX session — use AdsSdk.mrec")
            callback?.onAdFailedToLoad(AdError(message = "native bottom is AdMob-only"))
            return
        }
        val useCollapsible = config.collapsible &&
            NativeCollapPolicy.shouldUseCollapsible(config.showNativeSmall, config.reloadSec)
        if (useCollapsible) {
            AdsSdk.native.loadCollapsible(
                activity,
                container,
                NativeCollapConfig(
                    expandedUnitId = config.expandedUnitId,
                    collapsedUnitId = config.nativeAdUnitId,
                    reloadSecRemoteKey = null,
                    reloadSec = config.reloadSec,
                    collapsedNativeSmall = config.showNativeSmall,
                    collapsedBanner = config.banner,
                    expandedLayoutRes = config.expandedLayoutRes,
                    collapsedLayoutRes = config.collapsedLayoutRes,
                ),
                placement = placement,
                callback = callback,
            )
            return
        }
        if (config.showNativeSmall) {
            if (config.nativeLayoutRes != 0) {
                AdsSdk.native.loadAndBind(
                    activity,
                    container,
                    config.nativeAdUnitId,
                    config.nativeLayoutRes,
                    shimmer,
                    callback = callback,
                )
            } else {
                AdsSdk.native.loadAndBind(
                    activity,
                    container,
                    config.nativeAdUnitId,
                    NativeTemplate.Small,
                    shimmer,
                    callback = callback,
                )
            }
        } else {
            AdsSdk.banner.load(activity, container, shimmer, config.banner, callback)
        }
    }
}
