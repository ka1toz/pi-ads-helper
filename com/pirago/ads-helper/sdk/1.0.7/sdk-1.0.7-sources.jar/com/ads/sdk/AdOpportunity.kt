package com.ads.sdk

import com.ads.sdk.diagnostics.TraceRuntime

/**
 * One product chance to show an ad. Create it before the app's own gates.
 * Closing methods emit at most one `ads_opportunity_end`.
 */
class AdOpportunity internal constructor(
    val id: String,
    internal val formatWire: String,
) {
    fun skip(reason: String) = TraceRuntime.skip(this, reason)

    fun abandon(reason: String) = TraceRuntime.abandon(this, reason)

    /** App deadline elapsed. Does not cancel an in-flight ad load. */
    fun failTimeout() = TraceRuntime.failTimeout(this)

    /** View slot removed. Ends an still-open opportunity as `abandoned/screen_left`. */
    fun releaseSlot() = TraceRuntime.releaseSlot(this)
}
