package com.ads.sdk.internal

/** Immutable ownership for a real load cycle. Retry stays in it; refill starts a new one. */
class LoadCycles<K> {
    data class Cycle(val mode: String, val opportunityId: String?, val generation: Long)
    private val cycles = java.util.WeakHashMap<K, Cycle>()
    private var generation = 0L
    @Synchronized fun start(key: K, mode: String, opportunityId: String?): Cycle =
        Cycle(mode, opportunityId, ++generation).also { cycles[key] = it }
    @Synchronized fun get(key: K): Cycle? = cycles[key]
    @Synchronized fun current(key: K, cycle: Cycle) = cycles[key] == cycle
}
