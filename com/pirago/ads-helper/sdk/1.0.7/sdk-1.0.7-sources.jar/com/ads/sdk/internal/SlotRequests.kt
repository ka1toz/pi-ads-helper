package com.ads.sdk.internal

/** A request token outlives neither its slot nor a newer request, including deferred initialization. */
internal class SlotRequests<K>(private val release: (String) -> Unit) {
    data class Token(val opportunityId: String, val placement: String?, val generation: Long)
    private val slots = HashMap<K, Token>()
    private var generation = 0L

    @Synchronized
    fun begin(key: K, explicitId: String?, placement: String?, create: () -> String): Token {
        val previous = slots[key]
        val id = explicitId ?: previous?.takeIf { it.placement == placement }?.opportunityId ?: create()
        if (previous != null && previous.opportunityId != id) release(previous.opportunityId)
        return Token(id, placement, ++generation).also { slots[key] = it }
    }

    @Synchronized fun current(key: K, token: Token) = slots[key] == token
    @Synchronized fun remove(key: K) { slots.remove(key)?.let { release(it.opportunityId) } }
}
