package com.ads.sdk.analytics

import com.ads.sdk.DiagnosticsLogger
import com.ads.sdk.PaidAdEvent

/** Optional aggregate projection. SDK trace IDs remain in DiagnosticsLogger's raw-data sink.
 * This projection keeps opportunity-per-slot semantics; it is not a v3 refresh-tick counter.
 * Calling [onPaid] is opt-in: never combine manual revenue with automatic ad_impression.
 */
class ArlAnalyticsAdapter(private val log: (String, Map<String, Any>) -> Unit) : DiagnosticsLogger {
    override fun onDiagnostic(name: String, params: Map<String, Any>) {
        val event = when (name) {
            "ads_opportunity" -> "arl_ad_opportunity"
            "ads_load_start" -> "arl_ad_request"
            "ads_load_result" -> if (params["status"] == "success") "arl_ad_load_success" else "arl_ad_load_failed"
            "ads_show_start" -> "arl_ad_show_attempt"
            "ads_show_result" -> if (params["status"] == "failure") "arl_ad_show_failed" else return
            "ads_impression_observed" -> "arl_ad_impression_marker"
            "ads_click" -> "arl_ad_click"
            "ads_dismiss" -> "arl_ad_dismiss"
            "ads_reward_earned" -> "arl_ad_reward_earned"
            "ads_ad_discarded" -> "arl_ad_expired"
            "ads_opportunity_end" -> if (params["outcome"] == "skipped") "arl_ad_skipped" else return
            else -> return
        }
        val beforeShow = name in setOf("ads_load_start", "ads_load_result", "ads_ad_discarded")
        val out = linkedMapOf<String, Any>(
            "arl_placement" to ((params["placement"] as? String) ?: if (beforeShow) "shared_pool" else "unknown").take(100),
            "arl_format" to format(params["format"] as? String),
        )
        if (event.endsWith("_failed")) out["arl_failure_reason"] = failure(params["reason"] as? String)
        if (event == "arl_ad_skipped") out["arl_skip_reason"] = skip(params["reason"] as? String)
        runCatching { log(event, out) }
    }

    /** Only for the app's chosen manual Firebase revenue path, never for the diagnostic marker. */
    fun onPaid(event: PaidAdEvent) {
        if (!event.isBillable()) return
        val out = linkedMapOf<String, Any>(
            "value" to event.valueMicros / 1_000_000.0,
            "currency" to event.currencyCode.uppercase().take(100),
            "ad_platform" to event.adPlatform.lowercase().take(100),
            "ad_format" to format(event.adFormat),
            "ad_unit_name" to event.adUnitId.take(100),
            "arl_placement" to (event.placement ?: "unknown").take(100),
            "arl_ad_source_raw" to (event.adSource?.takeIf { it.isNotBlank() } ?: "unknown").take(100),
        )
        event.adSource?.takeIf { it.isNotBlank() }?.let { out["ad_source"] = it.take(100) }
        runCatching { log("ad_impression", out) }
    }

    private fun format(value: String?) = if (value == "mrec") "banner" else value ?: "unknown"
    private fun failure(value: String?) = when (value) {
        "no_fill", "invalid_request", "already_showing", "unknown" -> value
        "network_error" -> "network"
        "network_timeout", "app_timeout" -> "timeout"
        "internal_error" -> "internal"
        "cache_expired" -> "expired"
        "cache_empty", "ad_loading", "sdk_not_ready", "invalid_activity" -> "not_ready"
        else -> "unknown"
    }
    private fun skip(value: String?) = when (value) {
        "interval_blocked", "frequency_capped" -> "frequency_cap"
        "placement_disabled" -> "disabled_remote"
        "ads_removed" -> "premium"
        "consent_blocked" -> "consent"
        "already_showing" -> "already_showing"
        "cache_empty", "ad_loading", "sdk_not_ready" -> "not_ready"
        else -> "unknown"
    }
}
