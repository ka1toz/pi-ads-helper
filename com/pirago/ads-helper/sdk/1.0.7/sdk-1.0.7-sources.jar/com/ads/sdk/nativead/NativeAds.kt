package com.ads.sdk.nativead

import android.app.Activity
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.LayoutRes
import com.ads.sdk.AdsSdk
import com.ads.sdk.NativeTemplate
import com.ads.sdk.R
import com.ads.sdk.TraceFormat
import com.ads.sdk.callback.AdCallback
import com.ads.sdk.callback.AdError
import com.ads.sdk.diagnostics.TraceRuntime
import com.ads.sdk.diagnostics.admobLoadReason
import com.ads.sdk.internal.MainThread
import com.ads.sdk.internal.SdkLog
import com.ads.sdk.revenue.PaidEventMapper
import com.ads.sdk.TestAdUnits
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.VideoOptions
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import java.util.Collections

class NativeAds internal constructor() {

    private data class Cached(
        val ad: NativeAd,
        val loadedAt: Long = System.currentTimeMillis(),
    )

    private val cache = LinkedHashMap<String, Cached>()
    private val slots = com.ads.sdk.internal.SlotRequests<ViewGroup>(TraceRuntime::releaseId)

    /** AdLoader is not a static load API — GC before callback drops the native ad silently. */
    private val inFlightLoaders = Collections.synchronizedSet(mutableSetOf<AdLoader>())

    fun preload(context: Context, placement: String, adUnitId: String, callback: AdCallback? = null) {
        if (AdsSdk.deferUntilRemoteReady { preload(context, placement, adUnitId, callback) }) return
        if (AdsSdk.isMax) {
            SdkLog.w("Native preload skipped: MAX session")
            callback?.onAdFailedToLoad(AdError(message = "native is AdMob-only"))
            return
        }
        loadInternal(context, adUnitId, callback) { ad ->
            cache[placement]?.ad?.let { TraceRuntime.discard(it, "replaced"); it.destroy() }
            cache[placement] = Cached(ad)
        }
    }

    fun load(context: Context, adUnitId: String, callback: NativeLoadCallback) {
        if (AdsSdk.deferUntilRemoteReady { load(context, adUnitId, callback) }) return
        if (AdsSdk.isMax) {
            SdkLog.w("Native load skipped: MAX session")
            callback.onAdFailedToLoad(AdError(message = "native is AdMob-only"))
            return
        }
        loadInternal(context, adUnitId, callback) { ad ->
            callback.onNativeLoaded(ad)
        }
    }

    internal fun loadLinked(
        context: Context,
        adUnitId: String,
        opportunityId: String,
        callback: NativeLoadCallback,
    ) {
        if (AdsSdk.deferUntilRemoteReady { loadLinked(context, adUnitId, opportunityId, callback) }) return
        if (AdsSdk.isMax) {
            TraceRuntime.fail(opportunityId, "unsupported_format", "gate")
            callback.onAdFailedToLoad(AdError(message = "native is AdMob-only"))
            return
        }
        loadInternal(context, adUnitId, callback, opportunityId) { ad ->
            callback.onNativeLoaded(ad)
        }
    }

    fun takePreloaded(placement: String): NativeAd? {
        val cached = cache.remove(placement) ?: return null
        if (System.currentTimeMillis() - cached.loadedAt > TTL_MS) {
            TraceRuntime.discard(cached.ad, "ttl_expired")
            cached.ad.destroy()
            return null
        }
        return cached.ad
    }

    /** Manual bind path with product context. creative_bound does not assert visibility. */
    fun bind(nativeAd: NativeAd, adView: NativeAdView, opportunity: com.ads.sdk.AdOpportunity) {
        val showId = beginNativeShow(nativeAd, opportunity.id)
        bind(nativeAd, adView)
        TraceRuntime.showSuccess(TraceFormat.Native, "creative_bound", showId)
    }

    fun bind(nativeAd: NativeAd, adView: NativeAdView) {
        NativeAssetBinder.populate(adView, nativeAd)
        adView.setNativeAd(nativeAd)
    }

    /**
     * Inflate [layoutRes] into [container] and bind [nativeAd].
     *
     * Root may be a [NativeAdView], or a wrapper that contains one
     * (`@+id/nativeAdView` or `@+id/ads_sdk_native_ad_view`) — same pattern as
     * DIY fullscreen / collapsible layouts.
     */
    fun bind(
        activity: Activity,
        @LayoutRes layoutRes: Int,
        container: ViewGroup,
        nativeAd: NativeAd,
    ): NativeAdView {
        unbind(container, destroyAd = true, keepAd = nativeAd)
        val root = LayoutInflater.from(activity).inflate(layoutRes, container, false)
        val adView = NativeAssetBinder.findNativeAdView(root)
            ?: error(
                "Custom native layout must be a NativeAdView or contain one " +
                    "(id nativeAdView / ads_sdk_native_ad_view / native_ad_view)",
            )
        bind(nativeAd, adView)
        container.addView(root)
        container.setTag(R.id.ads_sdk_native_view, adView)
        container.setTag(R.id.ads_sdk_native_ad, nativeAd)
        container.visibility = View.VISIBLE
        container.requestLayout()
        return adView
    }

    fun bindTemplate(
        activity: Activity,
        container: ViewGroup,
        nativeAd: NativeAd,
        template: NativeTemplate,
    ): NativeAdView {
        return bind(activity, layoutFor(template), container, nativeAd)
    }

    fun loadAndBind(
        activity: Activity,
        container: ViewGroup,
        adUnitId: String,
        template: NativeTemplate = NativeTemplate.Medium,
        shimmer: View? = null,
        placement: String? = null,
        callback: AdCallback? = null,
    ) {
        loadAndBind(activity, container, adUnitId, layoutFor(template), shimmer, placement, callback)
    }

    fun loadAndBind(
        activity: Activity,
        container: ViewGroup,
        adUnitId: String,
        @LayoutRes layoutRes: Int,
        shimmer: View? = null,
        placement: String? = null,
        callback: AdCallback? = null,
    ) {
        val token = slots.begin(container, null, placement) {
            if (!placement.isNullOrBlank()) AdsSdk.openOpportunity(placement, TraceFormat.Native, "content").id
            else TraceRuntime.showOpportunity(null, TraceFormat.Native, "content")
        }
        loadAndBindRequest(activity, container, adUnitId, layoutRes, shimmer, placement, callback, token)
    }

    private fun loadAndBindRequest(
        activity: Activity, container: ViewGroup, adUnitId: String, layoutRes: Int,
        shimmer: View?, placement: String?, callback: AdCallback?,
        token: com.ads.sdk.internal.SlotRequests.Token,
    ) {
        if (!slots.current(container, token)) return
        if (AdsSdk.deferUntilRemoteReady {
            loadAndBindRequest(activity, container, adUnitId, layoutRes, shimmer, placement, callback, token)
        }) return
        val opp = token.opportunityId
        if (AdsSdk.isMax) {
            SdkLog.w("Native bind skipped: MAX session")
            shimmer?.visibility = View.GONE
            TraceRuntime.fail(opp, "unsupported_format", "gate")
            callback?.onAdFailedToLoad(AdError(message = "native is AdMob-only"))
            return
        }
        shimmer?.visibility = View.VISIBLE
        val preloaded = placement?.let { takePreloaded(it) }
        if (preloaded != null) {
            shimmer?.visibility = View.GONE
            TraceRuntime.noteCache(opp, "hit")
            val showId = beginNativeShow(preloaded, opp)
            bind(activity, layoutRes, container, preloaded)
            TraceRuntime.showSuccess(TraceFormat.Native, "view_attached", showId)
            callback?.onAdLoaded()
            return
        }
        TraceRuntime.noteCache(opp, "empty")
        loadInternal(
            activity,
            adUnitId,
            object : AdCallback {
                override fun onNextAction() = Unit
                override fun onAdFailedToLoad(error: AdError?) {
                    if (!slots.current(container, token)) return
                    shimmer?.visibility = View.GONE
                    callback?.onAdFailedToLoad(error)
                }
            },
            opp,
            isCurrent = { slots.current(container, token) && !activity.isDestroyed && !activity.isFinishing },
        ) { ad ->
            if (!slots.current(container, token) || activity.isDestroyed || activity.isFinishing) {
                TraceRuntime.discard(ad, "slot_removed")
                ad.destroy()
                return@loadInternal
            }
            shimmer?.visibility = View.GONE
            val showId = beginNativeShow(ad, opp)
            bind(activity, layoutRes, container, ad)
            TraceRuntime.showSuccess(TraceFormat.Native, "view_attached", showId)
            callback?.onAdLoaded()
        }
    }

    fun loadCollapsible(
        activity: Activity,
        container: ViewGroup,
        config: com.ads.sdk.NativeCollapConfig,
        placement: String? = null,
        callback: AdCallback? = null,
    ) {
        if (AdsSdk.deferUntilRemoteReady { loadCollapsible(activity, container, config, placement, callback) }) return
        if (AdsSdk.isMax) {
            SdkLog.w("Native collap skipped: MAX session")
            callback?.onAdFailedToLoad(AdError(message = "native is AdMob-only"))
            return
        }
        NativeCollapsibleController(this).attach(activity, container, config, placement, callback)
    }

    fun destroy(container: ViewGroup) {
        (container.getTag(R.id.ads_sdk_collap_controller) as? NativeCollapsibleController)?.release()
        container.setTag(R.id.ads_sdk_collap_controller, null)
        slots.remove(container)
        unbind(container, destroyAd = true, keepAd = null)
        container.removeAllViews()
    }

    internal fun destroyContents(container: ViewGroup) {
        unbind(container, destroyAd = true, keepAd = null)
        container.removeAllViews()
    }

    private fun unbind(container: ViewGroup, destroyAd: Boolean, keepAd: NativeAd?) {
        val ad = container.getTag(R.id.ads_sdk_native_ad) as? NativeAd
        container.setTag(R.id.ads_sdk_native_view, null)
        container.setTag(R.id.ads_sdk_native_ad, null)
        container.removeAllViews()
        if (destroyAd && ad != null && ad !== keepAd) {
            runCatching { TraceRuntime.discard(ad, "slot_removed"); ad.destroy() }
        }
    }

    /** For app-owned native ads. Emits discard only if this loaded ad has not impressed. */
    fun discard(ad: NativeAd, reason: String = "app_discarded") {
        TraceRuntime.discard(ad, reason)
        ad.destroy()
    }

    fun destroyPlacement(placement: String) {
        cache.remove(placement)?.ad?.let { TraceRuntime.discard(it, "cache_cleared"); it.destroy() }
    }

    internal fun layoutFor(template: NativeTemplate): Int = when (template) {
        NativeTemplate.Small -> R.layout.ads_native_small
        NativeTemplate.Medium -> R.layout.ads_native_medium
        NativeTemplate.MediumCtaFirst -> R.layout.ads_native_medium_cta_first
        NativeTemplate.Fullscreen -> R.layout.ads_native_fullscreen
    }

    private fun loadInternal(
        context: Context,
        adUnitId: String,
        callback: AdCallback?,
        opportunityId: String? = null,
        isCurrent: () -> Boolean = { true },
        onLoaded: (NativeAd) -> Unit,
    ) {
        requestNative(
            context.applicationContext,
            adUnitId,
            callback,
            onLoaded,
            debugFallbackUnit(adUnitId),
            opportunityId,
            retryIndex = 0,
            isCurrent = isCurrent,
        )
    }

    internal fun beginNativeShow(ad: NativeAd, opportunityId: String): String =
        TraceRuntime.showAd(TraceFormat.Native, ad, opportunityId, "attach")

    private fun debugFallbackUnit(adUnitId: String): String? {
        if (AdsSdk.configOrNull?.debug != true) return null
        return when (adUnitId) {
            TestAdUnits.NATIVE -> TestAdUnits.NATIVE_VIDEO
            TestAdUnits.NATIVE_VIDEO -> TestAdUnits.NATIVE
            else -> null
        }
    }

    private fun requestNative(
        app: Context,
        adUnitId: String,
        callback: AdCallback?,
        onLoaded: (NativeAd) -> Unit,
        fallbackAdUnitId: String?,
        opportunityId: String?,
        retryIndex: Int,
        isCurrent: () -> Boolean = { true },
    ) {
        val mode = when {
            retryIndex > 0 -> "retry"
            opportunityId == null -> "preload"
            else -> "on_demand"
        }
        AdsSdk.consent.initializeMobileAds(app) {
            if (!isCurrent()) return@initializeMobileAds
            val loadId = TraceRuntime.loadStart(TraceFormat.Native, adUnitId, mode, retryIndex, opportunityId)
            var loadedAd = java.lang.ref.WeakReference<NativeAd>(null)
            lateinit var loader: AdLoader
            loader = AdLoader.Builder(app, adUnitId)
                .forNativeAd { ad ->
                    inFlightLoaders.remove(loader)
                    loadedAd = java.lang.ref.WeakReference(ad)
                    TraceRuntime.rememberLoad(ad, loadId)
                    TraceRuntime.loadSuccess(
                        TraceFormat.Native,
                        ad.responseInfo?.loadedAdapterResponseInfo?.adSourceName,
                        loadId,
                    )
                    ad.setOnPaidEventListener { value ->
                        AdsSdk.paid(
                            TraceRuntime.paid(PaidEventMapper.map(value, ad.responseInfo, "native", adUnitId), ad),
                        )
                    }
                    SdkLog.d("Native loaded unit=$adUnitId headline=${ad.headline}")
                    MainThread.post { onLoaded(ad) }
                }
                .withAdListener(object : AdListener() {
                    override fun onAdFailedToLoad(error: LoadAdError) {
                        inFlightLoaders.remove(loader)
                        SdkLog.w("Native failed unit=$adUnitId ${error.code}: ${error.message}")
                        val reason = admobLoadReason(error.code)
                        TraceRuntime.loadFailure(TraceFormat.Native, reason, error.domain, error.code.toString(), loadId)
                        if (!isCurrent()) return
                        if (fallbackAdUnitId != null && fallbackAdUnitId != adUnitId) {
                            SdkLog.w("Native retry fallback=$fallbackAdUnitId")
                            requestNative(
                                app,
                                fallbackAdUnitId,
                                callback,
                                onLoaded,
                                fallbackAdUnitId = null,
                                opportunityId,
                                retryIndex + 1,
                                isCurrent,
                            )
                            return
                        }
                        opportunityId?.let { TraceRuntime.fail(it, reason, "load") }
                        MainThread.post {
                            callback?.onAdFailedToLoad(AdError(error.code, error.message))
                        }
                    }

                    override fun onAdClicked() {
                        TraceRuntime.lifecycleAd("ads_click", TraceFormat.Native, loadedAd.get())
                        callback?.onAdClicked()
                    }

                    override fun onAdImpression() {
                        TraceRuntime.impressionAd(TraceFormat.Native, loadedAd.get(), "admob_impression")
                        callback?.onAdImpression()
                    }
                })
                .withNativeAdOptions(
                    NativeAdOptions.Builder()
                        .setReturnUrlsForImageAssets(false)
                        .setVideoOptions(VideoOptions.Builder().setStartMuted(true).build())
                        .build(),
                )
                .build()
            inFlightLoaders.add(loader)
            loader.loadAd(AdRequest.Builder().build())
        }
    }

    internal fun populate(adView: NativeAdView, nativeAd: NativeAd) {
        NativeAssetBinder.populate(adView, nativeAd)
    }

    interface NativeLoadCallback : AdCallback {
        fun onNativeLoaded(ad: NativeAd)
    }

    private companion object {
        const val TTL_MS = 60 * 60 * 1000L
    }
}
