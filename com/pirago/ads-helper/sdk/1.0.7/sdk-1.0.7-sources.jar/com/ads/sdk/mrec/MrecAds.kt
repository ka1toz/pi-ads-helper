package com.ads.sdk.mrec

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import com.ads.sdk.AdOpportunity
import com.ads.sdk.AdsSdk
import com.ads.sdk.TraceFormat
import com.ads.sdk.callback.AdCallback
import com.ads.sdk.callback.AdError
import com.ads.sdk.diagnostics.TraceRuntime
import com.ads.sdk.internal.SdkLog

class MrecAds internal constructor() {

    private val slots = com.ads.sdk.internal.SlotRequests<ViewGroup>(TraceRuntime::releaseId)

    fun load(
        activity: Activity,
        container: ViewGroup,
        adUnitId: String,
        shimmer: View? = null,
        callback: AdCallback? = null
    ) {
        load(activity, container, adUnitId, shimmer, callback, opportunity = null)
    }

    fun load(
        activity: Activity,
        container: ViewGroup,
        adUnitId: String,
        shimmer: View? = null,
        callback: AdCallback? = null,
        opportunity: AdOpportunity?,
    ) {
        val token = slots.begin(container, opportunity?.id, null) {
            TraceRuntime.showOpportunity(opportunity, TraceFormat.Mrec, "content")
        }
        loadRequest(activity, container, adUnitId, shimmer, callback, token)
    }

    private fun loadRequest(activity: Activity, container: ViewGroup, adUnitId: String, shimmer: View?, callback: AdCallback?, token: com.ads.sdk.internal.SlotRequests.Token) {
        if (!slots.current(container, token)) return
        if (AdsSdk.deferUntilRemoteReady { loadRequest(activity, container, adUnitId, shimmer, callback, token) }) return
        val opp = token.opportunityId
        if (!AdsSdk.isMax) {
            SdkLog.w("MREC skipped: AdMob session")
            TraceRuntime.fail(opp, "unsupported_format", "gate")
            callback?.onAdFailedToLoad(AdError(message = "mrec is MAX-only"))
            return
        }
        if (adUnitId.isBlank()) {
            SdkLog.w("MREC skipped: empty ad unit")
            TraceRuntime.fail(opp, "missing_ad_unit", "gate")
            callback?.onAdFailedToLoad(AdError(message = "mrec ad unit empty"))
            return
        }
        val bridge = AdsSdk.maxBridge
        if (bridge == null) {
            SdkLog.w("MREC skipped: sdk-max not on classpath")
            TraceRuntime.fail(opp, "missing_backend", "gate")
            callback?.onAdFailedToLoad(AdError(message = "sdk-max missing"))
            return
        }
        AdsSdk.ensureNetworkSdk(activity.applicationContext) {
                if (!slots.current(container, token) || activity.isDestroyed || activity.isFinishing) return@ensureNetworkSdk
            bridge.loadMrec(activity, container, adUnitId, shimmer, callback, opp)
        }
    }

    fun destroy(container: ViewGroup) {
        slots.remove(container)
        AdsSdk.maxBridge?.destroyMrec(container)
    }
}
