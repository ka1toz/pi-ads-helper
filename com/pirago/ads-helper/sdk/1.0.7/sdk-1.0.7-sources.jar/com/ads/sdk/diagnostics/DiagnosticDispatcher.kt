package com.ads.sdk.diagnostics

import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit

/** Ordered, bounded delivery. A slow collector cannot block ad callbacks or grow memory forever. */
internal class DiagnosticDispatcher(capacity: Int = 256, private val onDrop: () -> Unit) {
    private val executor = ThreadPoolExecutor(1, 1, 30, TimeUnit.SECONDS,
        ArrayBlockingQueue<Runnable>(capacity),
        { runnable -> Thread(runnable, "ads-diagnostics").apply { isDaemon = true } },
        { _, _ -> onDrop() },
    ).apply { allowCoreThreadTimeOut(true) }

    fun dispatch(block: () -> Unit) { executor.execute { runCatching(block) } }
    internal fun close() { executor.shutdownNow() }
}
