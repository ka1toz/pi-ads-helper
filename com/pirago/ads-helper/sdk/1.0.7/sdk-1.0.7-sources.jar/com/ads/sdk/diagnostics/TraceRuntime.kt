package com.ads.sdk.diagnostics

import android.os.SystemClock
import com.ads.sdk.AdOpportunity
import com.ads.sdk.AdsSdk
import com.ads.sdk.BuildConfig
import com.ads.sdk.TraceFormat

/**
 * Process-wide trace. Emission never throws into the ad path.
 * A null [com.ads.sdk.DiagnosticsLogger] still updates state so a later close is single-shot.
 */
internal object TraceRuntime {
    private val dispatcher = DiagnosticDispatcher { com.ads.sdk.internal.SdkLog.w("Diagnostics queue full: event dropped") }
    private val engine = AdTraceEngine(
        nowMs = { SystemClock.elapsedRealtime() },
        sdkVersion = BuildConfig.SDK_VERSION,
        mediation = {
            when {
                !AdsSdk.traceMediationResolved -> "unresolved"
                AdsSdk.isMax -> "max"
                else -> "admob"
            }
        },
        onDrop = { com.ads.sdk.internal.SdkLog.w("Diagnostics evicted $it retained records") },
        emit = { name, params ->
            val logger = AdsSdk.configOrNull?.diagnosticsLogger
            if (logger != null) {
                val payload = DiagnosticPayload.sanitize(name, params)
                dispatcher.dispatch { logger.onDiagnostic(name, payload) }
            }
        },
    )

    private val adLoads = java.util.WeakHashMap<Any, String>()
    private val adShows = java.util.WeakHashMap<Any, String>()

    fun rememberLoad(ad: Any, attemptId: String) = synchronized(adLoads) { adLoads[ad] = attemptId }

    fun showAd(format: TraceFormat, ad: Any, opportunityId: String?, action: String): String {
        val loadId = synchronized(adLoads) { adLoads[ad] }
        val showId = showStart(format, opportunityId, action, loadId, useLatestLoad = false)
        synchronized(adShows) { adShows[ad] = showId }
        return showId
    }

    fun impressionAd(format: TraceFormat, ad: Any?, signal: String) {
        val showId = synchronized(adShows) { adShows[ad] }
        impression(format, signal, null, linked = showId != null, showAttemptId = showId, explicit = true)
    }

    fun lifecycle(event: String, format: TraceFormat, showId: String?, opportunityId: String? = null) =
        engine.lifecycle(event, format.wire, showId, opportunityId)

    fun lifecycleAd(event: String, format: TraceFormat, ad: Any?) =
        lifecycle(event, format, synchronized(adShows) { adShows[ad] })

    fun discardLoad(loadId: String?, reason: String) = engine.discard(loadId, reason)

    fun discard(ad: Any?, reason: String) = engine.discard(synchronized(adLoads) { adLoads[ad] }, reason)

    fun paid(event: com.ads.sdk.PaidAdEvent, ad: Any) = paidContext(event, synchronized(adShows) { adShows[ad] })

    fun paidContext(event: com.ads.sdk.PaidAdEvent, showId: String?, opportunityId: String? = null, linked: Boolean = true): com.ads.sdk.PaidAdEvent {
        val context = engine.context(showId, opportunityId)
        return event.copy(
            placement = context["placement"] as? String,
            opportunityId = context["opportunity_id"] as? String,
            loadAttemptId = if (linked) context["load_attempt_id"] as? String else null,
            showAttemptId = if (linked) context["show_attempt_id"] as? String else null,
        )
    }

    fun openProduct(placement: String, format: TraceFormat, trigger: String): AdOpportunity {
        val id = engine.openProduct(placement, format.wire, trigger)
        return remember(id, format.wire)
    }

    fun showOpportunity(passed: AdOpportunity?, format: TraceFormat, trigger: String): String {
        if (passed != null) {
            engine.bindSlot(format.wire, passed.id)
            return passed.id
        }
        val id = engine.openSdkEntry(format.wire, trigger)
        remember(id, format.wire)
        return id
    }

    fun skip(opportunity: AdOpportunity, reason: String) = engine.skip(opportunity.id, reason)

    fun skipId(opportunityId: String, reason: String) = engine.skip(opportunityId, reason)

    fun abandon(opportunity: AdOpportunity, reason: String) = engine.abandon(opportunity.id, reason)

    fun failTimeout(opportunity: AdOpportunity) = engine.fail(opportunity.id, "app_timeout", "gate")

    fun releaseSlot(opportunity: AdOpportunity) = engine.releaseSlot(opportunity.id)

    fun releaseId(opportunityId: String) = engine.releaseSlot(opportunityId)

    fun noteCache(opportunityId: String, state: String) = engine.noteCache(opportunityId, state)

    /** Context is supplied by the actual MAX load cycle, never a format-global arm. */
    fun onPlatformLoad(formatWire: String, adUnitId: String, retryIndex: Int, mode: String, opportunityId: String?): String? {
        val format = TraceFormat.entries.firstOrNull { it.wire == formatWire } ?: return null
        engine.clearReadyLoad(formatWire)
        return loadStart(format, adUnitId, if (retryIndex > 0) "retry" else mode, retryIndex, opportunityId)
    }

    fun loadStart(
        format: TraceFormat,
        adUnitId: String?,
        mode: String,
        retryIndex: Int,
        opportunityId: String?,
    ): String = engine.loadStart(format.wire, adUnitId, mode, retryIndex, opportunityId)

    fun loadSuccess(format: TraceFormat, adSource: String?, attemptId: String? = null) = engine.loadSuccess(format.wire, adSource, attemptId)

    fun loadFailure(format: TraceFormat, reason: String, domain: String?, code: String?, attemptId: String? = null) =
        engine.loadFailure(format.wire, reason, domain, code, attemptId)

    fun showStart(format: TraceFormat, opportunityId: String?, renderAction: String, loadAttemptId: String? = null, useLatestLoad: Boolean = true) =
        engine.showStart(format.wire, opportunityId, renderAction, loadAttemptId, useLatestLoad)

    fun showSuccess(format: TraceFormat, signal: String, attemptId: String? = null) = engine.showSuccess(format.wire, signal, attemptId)

    fun showFailure(format: TraceFormat, reason: String, domain: String?, code: String?, attemptId: String? = null) =
        engine.showFailure(format.wire, reason, domain, code, attemptId)

    fun impression(
        format: TraceFormat, signal: String, adSource: String?, linked: Boolean = true,
        showAttemptId: String? = null, opportunityId: String? = null, explicit: Boolean = false,
        impressionKey: String? = null,
    ) = engine.impression(format.wire, signal, adSource, linked, showAttemptId, opportunityId, explicit, impressionKey)

    fun fail(opportunityId: String, reason: String, stage: String) =
        engine.fail(opportunityId, reason, stage)

    private fun remember(id: String, format: String): AdOpportunity {
        val handle = AdOpportunity(id, format)
        return handle
    }
}

fun admobLoadReason(code: Int): String = when (code) {
    3, 9 -> "no_fill"
    2 -> "network_error"
    1 -> "invalid_request"
    0 -> "internal_error"
    else -> "load_error"
}
