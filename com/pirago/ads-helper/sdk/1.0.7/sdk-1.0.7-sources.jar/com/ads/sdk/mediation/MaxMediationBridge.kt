package com.ads.sdk.mediation

import android.app.Activity
import android.app.Application
import android.view.View
import android.view.ViewGroup
import com.ads.sdk.BannerConfig
import com.ads.sdk.callback.AdCallback

/**
 * Implemented in `:ads-sdk-max`. Loaded by reflection so `:ads-sdk` stays GMA-only
 * unless the app adds `sdk-max`.
 */
interface MaxMediationBridge {
    fun initialize(
        application: Application,
        sdkKey: String,
        testDeviceAdvertisingIds: List<String>,
        onComplete: () -> Unit,
    )

    fun loadBanner(
        activity: Activity,
        container: ViewGroup,
        shimmer: View?,
        config: BannerConfig,
        callback: AdCallback?,
    ) = loadBanner(activity, container, shimmer, config, callback, null)

    fun loadBanner(
        activity: Activity,
        container: ViewGroup,
        shimmer: View?,
        config: BannerConfig,
        callback: AdCallback?,
        opportunityId: String?,
    )

    fun hideBanner(container: ViewGroup)

    fun destroyBanner(container: ViewGroup)

    fun loadMrec(
        activity: Activity,
        container: ViewGroup,
        adUnitId: String,
        shimmer: View?,
        callback: AdCallback?,
    ) = loadMrec(activity, container, adUnitId, shimmer, callback, null)

    fun loadMrec(
        activity: Activity,
        container: ViewGroup,
        adUnitId: String,
        shimmer: View?,
        callback: AdCallback?,
        opportunityId: String?,
    )

    fun destroyMrec(container: ViewGroup)

    fun loadInterstitial(activity: Activity, adUnitId: String, callback: AdCallback?) =
        loadInterstitial(activity, adUnitId, callback, "preload", null)

    fun loadInterstitial(activity: Activity, adUnitId: String, callback: AdCallback?, loadMode: String, opportunityId: String?)

    fun isInterstitialReady(): Boolean

    fun showInterstitial(activity: Activity, callback: AdCallback, onClosed: () -> Unit) =
        showInterstitial(activity, callback, null, onClosed)

    fun showInterstitial(activity: Activity, callback: AdCallback, showAttemptId: String?, onClosed: () -> Unit)

    fun loadAppOpen(activity: Activity, adUnitId: String, callback: AdCallback?) =
        loadAppOpen(activity, adUnitId, callback, "preload", null)

    fun loadAppOpen(activity: Activity, adUnitId: String, callback: AdCallback?, loadMode: String, opportunityId: String?)

    fun isAppOpenReady(): Boolean

    fun showAppOpen(activity: Activity, callback: AdCallback) = showAppOpen(activity, callback, null)

    fun showAppOpen(activity: Activity, callback: AdCallback, showAttemptId: String?)

    /** Opens the MAX Mediation Debugger. Call only after [initialize] completes. */
    fun showMediationDebugger(activity: Activity)
}
