package com.ads.sdk.rewarded

import android.app.Activity
import com.ads.sdk.AdOpportunity
import com.ads.sdk.AdsSdk
import com.ads.sdk.FunnelEvent
import com.ads.sdk.TraceFormat
import com.ads.sdk.callback.AdCallback
import com.ads.sdk.callback.AdError
import com.ads.sdk.diagnostics.TraceRuntime
import com.ads.sdk.diagnostics.admobLoadReason
import com.ads.sdk.internal.SdkLog
import com.ads.sdk.revenue.PaidEventMapper
import com.ads.sdk.safeNext
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

class RewardedAds internal constructor() {

    @Volatile
    private var loaded: RewardedAd? = null

    fun isReady(): Boolean = loaded != null

    fun load(
        activity: Activity,
        adUnitId: String,
        callback: AdCallback? = null
    ) {
        load(activity, adUnitId, callback, opportunity = null)
    }

    fun load(
        activity: Activity,
        adUnitId: String,
        callback: AdCallback? = null,
        opportunity: AdOpportunity?,
    ) {
        if (AdsSdk.deferUntilRemoteReady { load(activity, adUnitId, callback, opportunity) }) return
        if (AdsSdk.isMax) {
            SdkLog.w("Rewarded skipped: MAX session has no rewarded unit")
            opportunity?.let { TraceRuntime.fail(it.id, "unsupported_format", "gate") }
            callback?.onAdFailedToLoad(AdError(message = "rewarded is AdMob-only"))
            return
        }
        val loadId = TraceRuntime.loadStart(
            TraceFormat.Rewarded,
            adUnitId,
            if (opportunity == null) "preload" else "on_demand",
            0,
            opportunity?.id,
        )
        AdsSdk.consent.initializeMobileAds(activity.applicationContext)
        RewardedAd.load(
            activity,
            adUnitId,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    loaded?.takeIf { it !== ad }?.let { TraceRuntime.discard(it, "replaced") }
                    loaded = ad
                    TraceRuntime.rememberLoad(ad, loadId)
                    TraceRuntime.loadSuccess(
                        TraceFormat.Rewarded,
                        ad.responseInfo.loadedAdapterResponseInfo?.adSourceName,
                        loadId,
                    )
                    ad.setOnPaidEventListener { value ->
                        AdsSdk.paid(
                            TraceRuntime.paid(PaidEventMapper.map(value, ad.responseInfo, "rewarded", adUnitId), ad),
                        )
                    }
                    AdsSdk.funnel(FunnelEvent.RewardedApiCalled)
                    callback?.onAdLoaded()
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    loaded?.let { TraceRuntime.discard(it, "load_failure_clear") }
                    loaded = null
                    TraceRuntime.loadFailure(
                        TraceFormat.Rewarded,
                        admobLoadReason(error.code),
                        error.domain,
                        error.code.toString(),
                        loadId,
                    )
                    callback?.onAdFailedToLoad(AdError(error.code, error.message))
                }
            },
        )
    }

    fun show(activity: Activity, callback: AdCallback) {
        show(activity, callback, opportunity = null)
    }

    fun show(activity: Activity, callback: AdCallback, opportunity: AdOpportunity?) {
        if (AdsSdk.deferUntilRemoteReady { show(activity, callback, opportunity) }) return
        val opp = TraceRuntime.showOpportunity(opportunity, TraceFormat.Rewarded, "content")
        if (AdsSdk.isMax) {
            TraceRuntime.fail(opp, "unsupported_format", "gate")
            callback.onAdFailedToLoad(AdError(message = "rewarded is AdMob-only"))
            callback.safeNext()
            return
        }
        AdsSdk.funnel(FunnelEvent.RewardedEligible)
        val ad = loaded
        if (ad == null) {
            TraceRuntime.noteCache(opp, "empty")
            TraceRuntime.fail(opp, "cache_empty", "show")
            callback.onAdFailedToLoad(AdError(message = "rewarded not loaded"))
            callback.safeNext()
            return
        }
        TraceRuntime.noteCache(opp, "hit")
        val showId = TraceRuntime.showAd(TraceFormat.Rewarded, ad, opp, "show")
        AdsSdk.appOpen.setShowingFullScreen(true)
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                TraceRuntime.showSuccess(TraceFormat.Rewarded, "fullscreen_shown", showId)
                AdsSdk.funnel(FunnelEvent.RewardedDisplayed)
                callback.onAdShown()
            }

            override fun onAdDismissedFullScreenContent() {
                TraceRuntime.lifecycle("ads_dismiss", TraceFormat.Rewarded, showId)
                AdsSdk.appOpen.setShowingFullScreen(false)
                loaded = null
                callback.onAdDismissed()
                callback.safeNext()
            }

            override fun onAdFailedToShowFullScreenContent(error: com.google.android.gms.ads.AdError) {
                AdsSdk.appOpen.setShowingFullScreen(false)
                loaded = null
                TraceRuntime.showFailure(TraceFormat.Rewarded, "show_error", error.domain, error.code.toString(), showId)
                callback.onAdFailedToLoad(AdError(error.code, error.message))
                callback.safeNext()
            }

            override fun onAdClicked() {
                TraceRuntime.lifecycle("ads_click", TraceFormat.Rewarded, showId)
                callback.onAdClicked()
            }
            override fun onAdImpression() {
                TraceRuntime.impression(TraceFormat.Rewarded, "admob_impression", null, showAttemptId = showId, explicit = true)
                callback.onAdImpression()
            }
        }
        ad.show(activity) { reward ->
            TraceRuntime.lifecycle("ads_reward_earned", TraceFormat.Rewarded, showId)
            callback.onUserEarnedReward(reward.amount, reward.type)
        }
    }
}
