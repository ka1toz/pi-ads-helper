package com.ads.sdk.revenue

import com.ads.sdk.PaidAdEvent
import com.google.android.gms.ads.AdValue
import com.google.android.gms.ads.ResponseInfo

internal object PaidEventMapper {
    fun map(
        adValue: AdValue,
        responseInfo: ResponseInfo?,
        adFormat: String,
        adUnitId: String,
    ): PaidAdEvent {
        val adapter = responseInfo?.loadedAdapterResponseInfo
        return PaidAdEvent(
            valueMicros = adValue.valueMicros,
            currencyCode = adValue.currencyCode,
            precision = adValue.precisionType,
            adSource = adapter?.adSourceName?.takeIf { it.isNotBlank() } ?: adapter?.adSourceInstanceName,
            adFormat = adFormat,
            adUnitId = adUnitId,
        )
    }

    fun toFirebaseParams(event: PaidAdEvent): Map<String, Any> {
        val value = event.valueMicros / 1_000_000.0
        val params = linkedMapOf<String, Any>(
            "ad_platform" to event.adPlatform,
            "ad_format" to event.adFormat,
            "ad_unit_name" to event.adUnitId,
            "value" to value,
            "currency" to event.currencyCode,
        )
        event.adSource?.takeIf { it.isNotBlank() }?.let { params["ad_source"] = it }
        return params
    }
}
