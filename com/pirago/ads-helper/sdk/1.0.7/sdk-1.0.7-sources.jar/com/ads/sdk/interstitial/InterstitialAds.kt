package com.ads.sdk.interstitial

import android.app.Activity
import com.ads.sdk.AdOpportunity
import com.ads.sdk.AdsSdk
import com.ads.sdk.FunnelEvent
import com.ads.sdk.InterShowReason
import com.ads.sdk.TraceFormat
import com.ads.sdk.callback.AdCallback
import com.ads.sdk.callback.AdError
import com.ads.sdk.diagnostics.TraceRuntime
import com.ads.sdk.diagnostics.admobLoadReason
import com.ads.sdk.internal.SdkLog
import com.ads.sdk.revenue.PaidEventMapper
import com.ads.sdk.safeNext
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

class InterstitialAds internal constructor() {

    @Volatile
    private var loaded: InterstitialAd? = null
    @Volatile
    private var loadedUnitId: String? = null
    @Volatile
    private var showing = false

    fun isReady(): Boolean = if (AdsSdk.isMax) {
        AdsSdk.maxBridge?.isInterstitialReady() == true
    } else {
        loaded != null
    }

    fun load(
        activity: Activity,
        adUnitId: String,
        callback: AdCallback? = null
    ) {
        load(activity, adUnitId, callback, opportunity = null)
    }

    fun load(
        activity: Activity,
        adUnitId: String,
        callback: AdCallback? = null,
        opportunity: AdOpportunity?,
    ) {
        if (AdsSdk.deferUntilRemoteReady { load(activity, adUnitId, callback, opportunity) }) return
        if (AdsSdk.isMax) {
            loadMax(activity, adUnitId, callback, opportunity?.id, preload = opportunity == null)
            return
        }
        val loadId = TraceRuntime.loadStart(TraceFormat.Interstitial, adUnitId, loadMode(opportunity), 0, opportunity?.id)
        AdsSdk.consent.initializeMobileAds(activity.applicationContext)
        InterstitialAd.load(
            activity,
            adUnitId,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    attach(ad, adUnitId)
                    TraceRuntime.rememberLoad(ad, loadId)
                    TraceRuntime.loadSuccess(TraceFormat.Interstitial, ad.responseInfo.loadedAdapterResponseInfo?.adSourceName, loadId)
                    AdsSdk.funnel(FunnelEvent.InterApiCalled)
                    callback?.onAdLoaded()
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    loaded?.let { TraceRuntime.discard(it, "load_failure_clear") }
                    loaded = null
                    TraceRuntime.loadFailure(
                        TraceFormat.Interstitial,
                        admobLoadReason(error.code),
                        error.domain,
                        error.code.toString(),
                        loadId,
                    )
                    callback?.onAdFailedToLoad(AdError(error.code, error.message))
                }
            },
        )
    }

    fun show(
        activity: Activity,
        callback: AdCallback,
        reason: InterShowReason = InterShowReason.Content
    ) {
        show(activity, callback, reason, opportunity = null)
    }

    fun show(
        activity: Activity,
        callback: AdCallback,
        reason: InterShowReason = InterShowReason.Content,
        opportunity: AdOpportunity?,
    ) {
        if (AdsSdk.deferUntilRemoteReady { show(activity, callback, reason, opportunity) }) return
        val opp = TraceRuntime.showOpportunity(opportunity, TraceFormat.Interstitial, reason.name.lowercase())
        AdsSdk.funnel(FunnelEvent.InterEligible)
        val ignoreInterval = reason != InterShowReason.Content
        if (!AdsSdk.interval.canShow(ignoreInterval)) {
            SdkLog.d("Interstitial skipped: interval ${AdsSdk.interval.remainingMs()}ms left")
            TraceRuntime.skipId(opp, "interval_blocked")
            callback.safeNext()
            return
        }
        val ad = loaded
        if (ad == null) {
            TraceRuntime.noteCache(opp, "empty")
            if (AdsSdk.isMax) {
                presentMax(activity, callback, reason, opp)
                return
            }
            TraceRuntime.fail(opp, "cache_empty", "show")
            callback.onAdFailedToLoad(AdError(message = "interstitial not loaded"))
            callback.safeNext()
            return
        }
        TraceRuntime.noteCache(opp, "hit")
        present(activity, ad, callback, reason, opp)
    }

    fun loadAndShow(
        activity: Activity,
        adUnitId: String,
        ignoreInterval: Boolean,
        callback: AdCallback,
        reason: InterShowReason = InterShowReason.Content
    ) {
        loadAndShow(activity, adUnitId, ignoreInterval, callback, reason, opportunity = null)
    }

    fun loadAndShow(
        activity: Activity,
        adUnitId: String,
        ignoreInterval: Boolean,
        callback: AdCallback,
        reason: InterShowReason = InterShowReason.Content,
        opportunity: AdOpportunity?,
    ) {
        if (AdsSdk.deferUntilRemoteReady {
                loadAndShow(activity, adUnitId, ignoreInterval, callback, reason, opportunity)
            }
        ) {
            return
        }
        val opp = TraceRuntime.showOpportunity(opportunity, TraceFormat.Interstitial, reason.name.lowercase())
        AdsSdk.funnel(FunnelEvent.InterEligible)
        val skipGate = ignoreInterval || reason != InterShowReason.Content
        if (!AdsSdk.interval.canShow(skipGate)) {
            SdkLog.d("Interstitial skipped: interval")
            TraceRuntime.skipId(opp, "interval_blocked")
            callback.safeNext()
            return
        }
        loaded?.takeIf { loadedUnitId == adUnitId }?.let { ad ->
            TraceRuntime.noteCache(opp, "hit")
            AdsSdk.funnel(FunnelEvent.InterApiCalled)
            present(activity, ad, callback, reason, opp)
            return
        }
        if (AdsSdk.isMax && AdsSdk.maxBridge?.isInterstitialReady() == true) {
            TraceRuntime.noteCache(opp, "hit")
            AdsSdk.funnel(FunnelEvent.InterApiCalled)
            presentMax(activity, callback, reason, opp)
            return
        }
        TraceRuntime.noteCache(opp, "empty")
        if (AdsSdk.isMax) {
            loadMax(activity, adUnitId, object : AdCallback by callback {
                override fun onAdLoaded() {
                    callback.onAdLoaded()
                    presentMax(activity, callback, reason, opp)
                }

                override fun onAdFailedToLoad(error: AdError?) {
                    callback.onAdFailedToLoad(error)
                    callback.safeNext()
                }

                override fun onNextAction() = Unit
            }, opportunityId = opp, preload = false)
            return
        }
        val loadId = TraceRuntime.loadStart(TraceFormat.Interstitial, adUnitId, "on_demand", 0, opp)
        AdsSdk.consent.initializeMobileAds(activity.applicationContext)
        InterstitialAd.load(
            activity,
            adUnitId,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    attach(ad, adUnitId)
                    TraceRuntime.rememberLoad(ad, loadId)
                    TraceRuntime.loadSuccess(
                        TraceFormat.Interstitial,
                        ad.responseInfo.loadedAdapterResponseInfo?.adSourceName,
                        loadId,
                    )
                    AdsSdk.funnel(FunnelEvent.InterApiCalled)
                    callback.onAdLoaded()
                    present(activity, ad, callback, reason, opp)
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    loaded?.let { TraceRuntime.discard(it, "load_failure_clear") }
                    loaded = null
                    TraceRuntime.loadFailure(
                        TraceFormat.Interstitial,
                        admobLoadReason(error.code),
                        error.domain,
                        error.code.toString(),
                        loadId,
                    )
                    TraceRuntime.fail(opp, admobLoadReason(error.code), "load")
                    callback.onAdFailedToLoad(AdError(error.code, error.message))
                    callback.safeNext()
                }
            },
        )
    }

    private fun attach(ad: InterstitialAd, adUnitId: String) {
        loaded?.takeIf { it !== ad }?.let { TraceRuntime.discard(it, "replaced") }
        loaded = ad
        loadedUnitId = adUnitId
        ad.setOnPaidEventListener { value ->
            AdsSdk.paid(
                TraceRuntime.paid(PaidEventMapper.map(value, ad.responseInfo, "interstitial", adUnitId), ad),
            )
        }
    }

    private fun present(
        activity: Activity,
        ad: InterstitialAd,
        callback: AdCallback,
        reason: InterShowReason,
        opportunityId: String,
    ) {
        if (showing) {
            TraceRuntime.skipId(opportunityId, "already_showing")
            callback.safeNext()
            return
        }
        showing = true
        AdsSdk.appOpen.setShowingFullScreen(true)
        val showId = TraceRuntime.showAd(TraceFormat.Interstitial, ad, opportunityId, "show")
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                TraceRuntime.showSuccess(TraceFormat.Interstitial, "fullscreen_shown", showId)
                AdsSdk.funnel(FunnelEvent.InterDisplayed)
                callback.onAdShown()
            }

            override fun onAdImpression() {
                TraceRuntime.impression(TraceFormat.Interstitial, "admob_impression", null, showAttemptId = showId, explicit = true)
                callback.onAdImpression()
            }

            override fun onAdClicked() {
                TraceRuntime.lifecycle("ads_click", TraceFormat.Interstitial, showId)
                callback.onAdClicked()
            }

            override fun onAdDismissedFullScreenContent() {
                TraceRuntime.lifecycle("ads_dismiss", TraceFormat.Interstitial, showId)
                showing = false
                AdsSdk.appOpen.setShowingFullScreen(false)
                loaded = null
                if (reason == InterShowReason.Content) {
                    AdsSdk.interval.markContentDismissed()
                }
                if (reason == InterShowReason.Resume) {
                    AdsSdk.resumeInterval.markContentDismissed()
                }
                callback.onAdDismissed()
                callback.safeNext()
            }

            override fun onAdFailedToShowFullScreenContent(error: com.google.android.gms.ads.AdError) {
                showing = false
                AdsSdk.appOpen.setShowingFullScreen(false)
                loaded = null
                TraceRuntime.showFailure(
                    TraceFormat.Interstitial,
                    "show_error",
                    error.domain,
                    error.code.toString(),
                    showId,
                )
                callback.onAdFailedToLoad(AdError(error.code, error.message))
                callback.safeNext()
            }
        }
        ad.show(activity)
    }

    private fun loadMax(
        activity: Activity,
        adUnitId: String,
        callback: AdCallback?,
        opportunityId: String?,
        preload: Boolean,
    ) {
        if (adUnitId.isBlank()) {
            opportunityId?.let { TraceRuntime.fail(it, "missing_ad_unit", "gate") }
            callback?.onAdFailedToLoad(AdError(message = "max interstitial unit empty"))
            return
        }
        val bridge = AdsSdk.maxBridge
        if (bridge == null) {
            opportunityId?.let { TraceRuntime.fail(it, "missing_backend", "gate") }
            callback?.onAdFailedToLoad(AdError(message = "sdk-max missing"))
            return
        }
        AdsSdk.ensureNetworkSdk(activity.applicationContext) {
            bridge.loadInterstitial(
                activity,
                adUnitId,
                object : AdCallback {
                    override fun onNextAction() = Unit
                    override fun onAdLoaded() {
                        AdsSdk.funnel(FunnelEvent.InterApiCalled)
                        callback?.onAdLoaded()
                    }
                    override fun onAdFailedToLoad(error: AdError?) {
                        callback?.onAdFailedToLoad(error)
                    }
                },
                if (preload) "preload" else "on_demand",
                opportunityId,
            )
        }
    }

    private fun presentMax(
        activity: Activity,
        callback: AdCallback,
        reason: InterShowReason,
        opportunityId: String,
    ) {
        val bridge = AdsSdk.maxBridge
        if (bridge == null || !bridge.isInterstitialReady()) {
            TraceRuntime.fail(opportunityId, "cache_empty", "show")
            callback.onAdFailedToLoad(AdError(message = "max interstitial not loaded"))
            callback.safeNext()
            return
        }
        if (showing) {
            TraceRuntime.skipId(opportunityId, "already_showing")
            callback.safeNext()
            return
        }
        showing = true
        AdsSdk.appOpen.setShowingFullScreen(true)
        val showId = TraceRuntime.showStart(TraceFormat.Interstitial, opportunityId, "show")
        val shown = object : AdCallback by callback {
            override fun onAdShown() {
                TraceRuntime.showSuccess(TraceFormat.Interstitial, "max_displayed", showId)
                AdsSdk.funnel(FunnelEvent.InterDisplayed)
                callback.onAdShown()
            }
            override fun onAdFailedToLoad(error: AdError?) {
                TraceRuntime.showFailure(
                    TraceFormat.Interstitial,
                    "show_error",
                    "max",
                    error?.code?.toString(),
                    showId,
                )
                callback.onAdFailedToLoad(error)
            }
            override fun onNextAction() = Unit
        }
        bridge.showInterstitial(activity, shown, showId) {
            showing = false
            AdsSdk.appOpen.setShowingFullScreen(false)
            if (reason == InterShowReason.Content) {
                AdsSdk.interval.markContentDismissed()
            }
            if (reason == InterShowReason.Resume) {
                AdsSdk.resumeInterval.markContentDismissed()
            }
            callback.onAdDismissed()
            callback.safeNext()
        }
    }

    private fun loadMode(opportunity: AdOpportunity?): String =
        if (opportunity == null) "preload" else "on_demand"
}
