package com.ads.sdk.banner

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.ads.sdk.AdOpportunity
import com.ads.sdk.AdsSdk
import com.ads.sdk.BannerConfig
import com.ads.sdk.BannerType
import com.ads.sdk.R
import com.ads.sdk.TraceFormat
import com.ads.sdk.callback.AdCallback
import com.ads.sdk.callback.AdError
import com.ads.sdk.diagnostics.TraceRuntime
import com.ads.sdk.diagnostics.admobLoadReason
import com.ads.sdk.internal.SdkLog
import com.ads.sdk.revenue.PaidEventMapper
import com.google.ads.mediation.admob.AdMobAdapter
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError

class BannerAds internal constructor() {

    private val handler = Handler(Looper.getMainLooper())
    private val slots = com.ads.sdk.internal.SlotRequests<ViewGroup>(TraceRuntime::releaseId)

    fun load(
        activity: Activity,
        container: ViewGroup,
        shimmer: View? = null,
        config: BannerConfig,
        callback: AdCallback? = null
    ) {
        load(activity, container, shimmer, config, callback, opportunity = null)
    }

    fun load(
        activity: Activity,
        container: ViewGroup,
        shimmer: View? = null,
        config: BannerConfig,
        callback: AdCallback? = null,
        opportunity: AdOpportunity?,
    ) {
        val token = slots.begin(container, opportunity?.id, null) {
            TraceRuntime.showOpportunity(opportunity, TraceFormat.Banner, "content")
        }
        loadRequest(activity, container, shimmer, config, callback, token)
    }

    private fun loadRequest(activity: Activity, container: ViewGroup, shimmer: View?, config: BannerConfig, callback: AdCallback?, token: com.ads.sdk.internal.SlotRequests.Token) {
        if (!slots.current(container, token)) return
        if (AdsSdk.deferUntilRemoteReady { loadRequest(activity, container, shimmer, config, callback, token) }) return
        destroy(container, releaseOpportunity = false)
        val opp = token.opportunityId
        if (AdsSdk.isMax) {
            val bridge = AdsSdk.maxBridge
            if (bridge == null || config.adUnitId.isBlank()) {
                SdkLog.w("Banner skipped: MAX backend or unit missing")
                shimmer?.visibility = View.GONE
                TraceRuntime.fail(opp, if (config.adUnitId.isBlank()) "missing_ad_unit" else "missing_backend", "gate")
                callback?.onAdFailedToLoad(AdError(message = "max banner unavailable"))
                return
            }
            AdsSdk.ensureNetworkSdk(activity.applicationContext) {
                if (!slots.current(container, token) || activity.isDestroyed || activity.isFinishing) return@ensureNetworkSdk
                bridge.loadBanner(activity, container, shimmer, config, callback, opp)
            }
            return
        }
        AdsSdk.consent.initializeMobileAds(activity.applicationContext)
        shimmer?.visibility = View.VISIBLE
        val adView = AdView(activity)
        adView.adUnitId = config.adUnitId
        adView.setAdSize(resolveSize(activity, container, config.type))
        container.addView(
            adView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )
        container.setTag(R.id.ads_sdk_banner_view, adView)
        val loadId = TraceRuntime.loadStart(TraceFormat.Banner, config.adUnitId, "on_demand", 0, opp)
        TraceRuntime.rememberLoad(adView, loadId)
        val showId = TraceRuntime.showStart(TraceFormat.Banner, opp, "attach", loadId, useLatestLoad = false)
        TraceRuntime.showSuccess(TraceFormat.Banner, "view_attached", showId)
        var firstLoadResult = true
        var linkedImpression = true
        var creativeGeneration = 0
        adView.setOnPaidEventListener { value ->
            AdsSdk.paid(
                TraceRuntime.paidContext(PaidEventMapper.map(value, adView.responseInfo, "banner", config.adUnitId), showId, opp, linkedImpression),
            )
        }
        adView.adListener = object : AdListener() {
            override fun onAdLoaded() {
                creativeGeneration++
                linkedImpression = firstLoadResult
                if (firstLoadResult) {
                    TraceRuntime.loadSuccess(TraceFormat.Banner, adView.responseInfo?.loadedAdapterResponseInfo?.adSourceName, loadId)
                    firstLoadResult = false
                }
                if (!slots.current(container, token)) return
                shimmer?.visibility = View.GONE
                callback?.onAdLoaded()
                scheduleRefresh(activity, container, shimmer, config, token)
            }

            override fun onAdFailedToLoad(error: LoadAdError) {
                if (firstLoadResult) {
                    TraceRuntime.loadFailure(TraceFormat.Banner, admobLoadReason(error.code), error.domain, error.code.toString(), loadId)
                    firstLoadResult = false
                }
                if (!slots.current(container, token)) return
                shimmer?.visibility = View.GONE
                TraceRuntime.fail(opp, admobLoadReason(error.code), "load")
                callback?.onAdFailedToLoad(AdError(error.code, error.message))
            }

            override fun onAdClicked() {
                TraceRuntime.lifecycle("ads_click", TraceFormat.Banner, if (linkedImpression) showId else null, opp)
                callback?.onAdClicked()
            }
            override fun onAdImpression() {
                TraceRuntime.impression(TraceFormat.Banner, "admob_impression", null, linkedImpression, showId, opp, explicit = true, impressionKey = "$showId:$creativeGeneration")
                callback?.onAdImpression()
            }
            override fun onAdOpened() = callback?.onAdShown() ?: Unit
        }
        adView.loadAd(buildRequest(config))
    }

    fun hide(container: ViewGroup) {
        if (AdsSdk.isMax) {
            AdsSdk.maxBridge?.hideBanner(container)
            container.visibility = View.GONE
            return
        }
        (container.getTag(R.id.ads_sdk_banner_view) as? AdView)?.visibility = View.GONE
        container.visibility = View.GONE
    }

    fun destroy(container: ViewGroup) {
        destroy(container, releaseOpportunity = true)
    }

    private fun destroy(container: ViewGroup, releaseOpportunity: Boolean) {
        if (releaseOpportunity) {
            slots.remove(container)
        }
        cancelRefresh(container)
        AdsSdk.maxBridge?.destroyBanner(container)
        val adView = container.getTag(R.id.ads_sdk_banner_view) as? AdView
        adView?.let { TraceRuntime.discard(it, "slot_removed") }
        adView?.destroy()
        container.setTag(R.id.ads_sdk_banner_view, null)
        if (adView != null) container.removeView(adView)
    }

    private fun scheduleRefresh(
        activity: Activity,
        container: ViewGroup,
        shimmer: View?,
        config: BannerConfig,
        request: com.ads.sdk.internal.SlotRequests.Token,
    ) {
        cancelRefresh(container)
        val sec = when (config.type) {
            BannerType.CollapsibleTop, BannerType.CollapsibleBottom ->
                config.collapsibleFetchIntervalSec.takeIf { it > 0 } ?: config.refreshSec
            else -> config.refreshSec
        }
        if (sec <= 0) return
        val token = Runnable {
            if (!slots.current(container, request) || activity.isDestroyed || activity.isFinishing) return@Runnable
            load(activity, container, shimmer, config)
        }
        container.setTag(R.id.ads_sdk_banner_refresh, token)
        handler.postDelayed(token, sec * 1000L)
    }

    private fun cancelRefresh(container: ViewGroup) {
        val token = container.getTag(R.id.ads_sdk_banner_refresh) as? Runnable
        if (token != null) handler.removeCallbacks(token)
        container.setTag(R.id.ads_sdk_banner_refresh, null)
    }

    private fun buildRequest(config: BannerConfig): AdRequest {
        val builder = AdRequest.Builder()
        val collapsible = when (config.type) {
            BannerType.CollapsibleTop -> "top"
            BannerType.CollapsibleBottom -> "bottom"
            else -> null
        }
        if (collapsible != null) {
            val extras = Bundle()
            extras.putString("collapsible", collapsible)
            builder.addNetworkExtrasBundle(AdMobAdapter::class.java, extras)
        }
        return builder.build()
    }

    private fun resolveSize(activity: Activity, container: ViewGroup, type: BannerType): AdSize {
        return when (type) {
            BannerType.Standard -> AdSize.BANNER
            BannerType.Large -> AdSize.LARGE_BANNER
            BannerType.Adaptive,
            BannerType.CollapsibleTop,
            BannerType.CollapsibleBottom,
            -> {
                val widthPx = container.width.takeIf { it > 0 }
                    ?: activity.resources.displayMetrics.widthPixels
                val density = activity.resources.displayMetrics.density
                val widthDp = (widthPx / density).toInt().coerceAtLeast(320)
                AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, widthDp)
            }
        }
    }
}
