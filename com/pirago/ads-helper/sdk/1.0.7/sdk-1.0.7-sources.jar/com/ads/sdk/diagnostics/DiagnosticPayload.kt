package com.ads.sdk.diagnostics

/** Pure serializer shared by all diagnostics. Never forwards arbitrary logger fields. */
internal object DiagnosticPayload {
    private val common = setOf("event_id", "schema_version", "mediation", "format", "sdk_version", "opportunity_id", "placement", "opportunity_scope")
    private val fields = mapOf(
        "ads_opportunity" to setOf("trigger"),
        "ads_opportunity_end" to setOf("trigger", "outcome", "stage", "elapsed_ms", "cache_state", "reason"),
        "ads_load_start" to setOf("load_attempt_id", "load_mode", "retry_index", "ad_unit_id"),
        "ads_load_result" to setOf("load_attempt_id", "status", "latency_ms", "reason", "error_domain", "error_code", "ad_source", "ad_unit_id"),
        "ads_show_start" to setOf("show_attempt_id", "load_attempt_id", "render_action", "cache_age_ms"),
        "ads_show_result" to setOf("show_attempt_id", "status", "signal", "latency_ms", "reason", "error_domain", "error_code"),
        "ads_impression_observed" to setOf("show_attempt_id", "load_attempt_id", "signal", "ad_source", "ad_unit_id", "is_late", "observation_scope"),
        "ads_ad_discarded" to setOf("load_attempt_id", "reason", "cache_age_ms", "ad_unit_id"),
        "ads_click" to setOf("show_attempt_id", "load_attempt_id"),
        "ads_dismiss" to setOf("show_attempt_id", "load_attempt_id"),
        "ads_reward_earned" to setOf("show_attempt_id", "load_attempt_id"),
    )

    fun sanitize(name: String, params: Map<String, Any>): Map<String, Any> {
        val allowed = common + (fields[name] ?: return emptyMap())
        return params.entries.filter { it.key in allowed }.take(25).mapNotNull { (key, value) ->
            val safe: Any = when (value) {
                is String -> if (key.endsWith("_id") && value.length > 100) return@mapNotNull null else value.take(100)
                is Long -> value
                is Int -> value.toLong()
                else -> return@mapNotNull null
            }
            key to safe
        }.toMap()
    }
}
