package com.ads.sdk.diagnostics

import java.util.ArrayDeque
import java.util.concurrent.atomic.AtomicLong
import java.util.UUID

/**
 * Opportunity / load / show state machine for `ads_*` diagnostics.
 * Emits at most one result per attempt and one end per opportunity.
 * Logger failures are the caller's problem; this class only records facts it is given.
 */
internal class AdTraceEngine(
    private val nowMs: () -> Long,
    private val sdkVersion: String,
    private val mediation: () -> String,
    private val emit: (name: String, params: Map<String, Any>) -> Unit,
    private val maxEntries: Int = 2048,
    private val retentionMs: Long = 24 * 60 * 60 * 1000L,
    private val onDrop: (Int) -> Unit = {},
) {
    private val seq = AtomicLong()
    private val processId = UUID.randomUUID().toString()
    private val lock = Any()
    private val opportunities = LinkedHashMap<String, Opp>()
    private val loads = LinkedHashMap<String, Attempt>()
    private val shows = LinkedHashMap<String, Attempt>()
    private val openLoads = HashMap<String, ArrayDeque<String>>()
    private val openShows = HashMap<String, ArrayDeque<String>>()
    private val readyLoad = HashMap<String, String>()
    private val slotOpportunity = HashMap<String, String>()

    fun clearReadyLoad(format: String) = synchronized(lock) { readyLoad.remove(format) }

    fun openProduct(placement: String, format: String, trigger: String): String =
        open(placement, format, trigger, SCOPE_PRODUCT)

    fun openSdkEntry(format: String, trigger: String): String =
        open(if (trigger == "resume") "app_resume" else PLACEMENT_UNKNOWN, format, trigger, SCOPE_SDK_ENTRY)

    fun skip(opportunityId: String, reason: String) {
        synchronized(lock) {
            val opp = opportunities[opportunityId] ?: return
            end(opp, OUTCOME_SKIPPED, reason, STAGE_GATE)
        }
    }

    fun abandon(opportunityId: String, reason: String) {
        synchronized(lock) {
            val opp = opportunities[opportunityId] ?: return
            end(opp, OUTCOME_ABANDONED, reason, STAGE_GATE)
        }
    }

    fun fail(opportunityId: String, reason: String, stage: String) {
        synchronized(lock) {
            val opp = opportunities[opportunityId] ?: return
            end(opp, OUTCOME_FAILED, reason, stage)
        }
    }

    /** Slot teardown. An already-ended opportunity is dropped. An open one closes as left. */
    fun releaseSlot(opportunityId: String) {
        synchronized(lock) {
            val opp = opportunities[opportunityId] ?: return
            if (!opp.ended) end(opp, OUTCOME_ABANDONED, "screen_left", STAGE_GATE)
            opp.released = true
            slotOpportunity.entries.removeAll { it.value == opportunityId }
        }
    }

    fun noteCache(opportunityId: String, state: String) {
        synchronized(lock) {
            val opp = opportunities[opportunityId] ?: return
            if (opp.cacheLocked) return
            opp.cacheState = state
            opp.cacheLocked = true
        }
    }

    fun loadStart(
        format: String,
        adUnitId: String?,
        mode: String,
        retryIndex: Int,
        opportunityId: String?,
    ): String {
        synchronized(lock) {
            prune()
            val id = nextId("l")
            val attempt = Attempt(
                id = id,
                format = format,
                opportunityId = opportunityId,
                startedAt = nowMs(),
                adUnitId = adUnitId,
                mode = mode,
                retryIndex = retryIndex,
            )
            loads[id] = attempt
            openLoads.getOrPut(format) { ArrayDeque() }.addLast(id)
            opportunityId?.let { opportunities[it]?.adUnitId = adUnitId }
            emit(
                "ads_load_start",
                envelope(format, opportunityId) + mapOf(
                    "load_attempt_id" to id,
                    "load_mode" to mode,
                    "retry_index" to retryIndex.toLong(),
                ) + unit(adUnitId),
            )
            return id
        }
    }

    fun loadSuccess(format: String, adSource: String?, attemptId: String? = null) {
        synchronized(lock) {
            val attempt = if (attemptId != null) loads[attemptId] else pollLoad(format)
            if (attempt == null || attempt.format != format) return
            if (attempt.done) return
            attempt.done = true
            attempt.completedAt = nowMs()
            readyLoad[format] = attempt.id
            openLoads[format]?.remove(attempt.id)
            emit(
                "ads_load_result",
                envelope(format, attempt.opportunityId) + mapOf(
                    "load_attempt_id" to attempt.id,
                    "status" to "success",
                    "latency_ms" to (nowMs() - attempt.startedAt).coerceAtLeast(0),
                ) + source(adSource) + unit(attempt.adUnitId),
            )
        }
    }

    fun loadFailure(format: String, reason: String, domain: String?, code: String?, attemptId: String? = null) {
        synchronized(lock) {
            val attempt = if (attemptId != null) loads[attemptId] else pollLoad(format)
            if (attempt == null || attempt.format != format) return
            if (attempt.done) return
            attempt.done = true
            openLoads[format]?.remove(attempt.id)
            val extra = LinkedHashMap<String, Any>()
            extra["load_attempt_id"] = attempt.id
            extra["status"] = "failure"
            extra["latency_ms"] = (nowMs() - attempt.startedAt).coerceAtLeast(0)
            extra["reason"] = reason
            if (!domain.isNullOrBlank()) extra["error_domain"] = domain
            if (!code.isNullOrBlank()) extra["error_code"] = code
            emit(
                "ads_load_result",
                envelope(format, attempt.opportunityId) + extra + unit(attempt.adUnitId),
            )
        }
    }

    fun showStart(
        format: String,
        opportunityId: String?,
        renderAction: String,
        loadAttemptId: String? = null,
        useLatestLoad: Boolean = true,
    ): String {
        synchronized(lock) {
            prune()
            val loadId = loadAttemptId ?: if (useLatestLoad) readyLoad[format] else null
            val id = nextId("s")
            val attempt = Attempt(
                id = id,
                format = format,
                opportunityId = opportunityId,
                startedAt = nowMs(),
                adUnitId = loads[loadId]?.adUnitId ?: opportunityId?.let { opportunities[it]?.adUnitId },
                mode = renderAction,
                retryIndex = 0,
                loadAttemptId = loadId,
            )
            shows[id] = attempt
            openShows.getOrPut(format) { ArrayDeque() }.addLast(id)
            opportunityId?.let { slotOpportunity[format] = it }
            val params = LinkedHashMap<String, Any>()
            params.putAll(envelope(format, opportunityId))
            params["show_attempt_id"] = id
            params["render_action"] = renderAction
            if (loadId != null) {
                params["load_attempt_id"] = loadId
                loads[loadId]?.let { load ->
                    load.completedAt?.let { params["cache_age_ms"] = (nowMs() - it).coerceAtLeast(0) }
                }
            }
            emit("ads_show_start", params)
            return id
        }
    }

    fun showSuccess(format: String, signal: String, attemptId: String? = null) {
        synchronized(lock) {
            val attempt = if (attemptId != null) shows[attemptId] else pollShow(format)
            if (attempt == null || attempt.format != format) return
            if (attempt.done) return
            attempt.done = true
            openShows[format]?.remove(attempt.id)
            emit(
                "ads_show_result",
                envelope(format, attempt.opportunityId) + mapOf(
                    "show_attempt_id" to attempt.id,
                    "status" to "success",
                    "signal" to signal,
                    "latency_ms" to (nowMs() - attempt.startedAt).coerceAtLeast(0),
                ),
            )
        }
    }

    fun showFailure(format: String, reason: String, domain: String?, code: String?, attemptId: String? = null) {
        synchronized(lock) {
            val attempt = if (attemptId != null) shows[attemptId] else pollShow(format)
            if (attempt == null || attempt.format != format) return
            if (attempt.done) return
            attempt.done = true
            openShows[format]?.remove(attempt.id)
            val extra = LinkedHashMap<String, Any>()
            extra["show_attempt_id"] = attempt.id
            extra["status"] = "failure"
            extra["latency_ms"] = (nowMs() - attempt.startedAt).coerceAtLeast(0)
            extra["reason"] = reason
            if (!domain.isNullOrBlank()) extra["error_domain"] = domain
            if (!code.isNullOrBlank()) extra["error_code"] = code
            emit("ads_show_result", envelope(format, attempt.opportunityId) + extra)
            attempt.opportunityId?.let { id ->
                opportunities[id]?.let { end(it, OUTCOME_FAILED, reason, STAGE_SHOW) }
            }
        }
    }

    /**
     * @param linked false when a refresh has no load/show start. Those impressions
     * stay on the slot opportunity for volume and do not open a new end.
     */
    fun impression(
        format: String, signal: String, adSource: String?, linked: Boolean,
        showAttemptId: String? = null, opportunityId: String? = null, explicit: Boolean = false,
        impressionKey: String? = null,
    ) {
        synchronized(lock) {
            val show = showAttemptId?.let { shows[it] }
            val key = impressionKey ?: if (format != "banner" && format != "mrec") show?.loadAttemptId ?: showAttemptId else null
            if (key != null && !once("impression:$key")) return
            show?.impressed = true
            show?.loadAttemptId?.let { loads[it]?.impressed = true }
            val resolvedOpportunity = opportunityId ?: show?.opportunityId ?: if (explicit) null else slotOpportunity[format]
            val opp = resolvedOpportunity?.let { opportunities[it] }
            val params = LinkedHashMap<String, Any>()
            params.putAll(envelope(format, resolvedOpportunity))
            params["signal"] = signal
            if (linked && show != null) {
                params["show_attempt_id"] = show.id
                show.loadAttemptId?.let { params["load_attempt_id"] = it }
                params.putAll(unit(show.adUnitId))
            }
            if (opp?.released == true || (opp?.ended == true && opp.outcome != OUTCOME_IMPRESSION)) params["is_late"] = 1L
            if (!linked) params["observation_scope"] = "refresh_unlinked"
            adSource?.takeIf { it.isNotBlank() }?.let { params["ad_source"] = it }
            emit("ads_impression_observed", params)
            if (opp != null && !opp.ended) {
                end(opp, OUTCOME_IMPRESSION, reason = null, STAGE_IMPRESSION)
            }
        }
    }

    fun bindSlot(format: String, opportunityId: String) {
        synchronized(lock) { slotOpportunity[format] = opportunityId }
    }

    private fun open(placement: String, format: String, trigger: String, scope: String): String {
        synchronized(lock) {
            prune()
            val id = nextId("o")
            val opp = Opp(id, placement.ifBlank { PLACEMENT_UNKNOWN }, format, trigger, scope, nowMs())
            opportunities[id] = opp
            emit(
                "ads_opportunity",
                envelope(format, id) + mapOf(
                    "placement" to opp.placement,
                    "trigger" to trigger,
                    "opportunity_scope" to scope,
                ),
            )
            return id
        }
    }

    private fun end(opp: Opp, outcome: String, reason: String?, stage: String) {
        if (opp.ended) return
        opp.ended = true
        opp.outcome = outcome
        val params = LinkedHashMap<String, Any>()
        params.putAll(envelope(opp.format, opp.id))
        params["placement"] = opp.placement
        params["opportunity_scope"] = opp.scope
        params["trigger"] = opp.trigger
        params["outcome"] = outcome
        params["stage"] = stage
        params["elapsed_ms"] = (nowMs() - opp.openedAt).coerceAtLeast(0)
        params["cache_state"] = opp.cacheState
        if (outcome != OUTCOME_IMPRESSION && !reason.isNullOrBlank()) params["reason"] = reason
        emit("ads_opportunity_end", params)
    }

    /** Snapshot from the exact show, retained after teardown for late paid callbacks. */
    fun context(showId: String?, opportunityId: String? = null): Map<String, Any> = synchronized(lock) {
        val show = shows[showId]
        val oppId = opportunityId ?: show?.opportunityId
        val result = linkedMapOf<String, Any>()
        oppId?.let { result["opportunity_id"] = it }
        opportunities[oppId]?.let { result["placement"] = it.placement }
        show?.let {
            result["show_attempt_id"] = it.id
            it.loadAttemptId?.let { id -> result["load_attempt_id"] = id }
        }
        result
    }

    fun lifecycle(event: String, format: String, showId: String?, opportunityId: String? = null) {
        if (event !in setOf("ads_click", "ads_dismiss", "ads_reward_earned")) return
        synchronized(lock) {
            val show = shows[showId]
            // Clicks can legitimately repeat; reward/dismiss are once per show.
            if (event != "ads_click" && showId != null && !once("$event:$showId")) return
            val oppId = opportunityId ?: show?.opportunityId
            emit(event, envelope(format, oppId) + context(showId, oppId))
        }
    }

    fun discard(loadId: String?, reason: String) {
        synchronized(lock) {
            val load = loads[loadId] ?: return
            if (!load.done || load.completedAt == null || load.impressed) return
            val show = shows.values.lastOrNull { it.loadAttemptId == loadId }
            // A fullscreen cache reference can be replaced while the old ad is presenting.
            // Its eventual paid/impression callback is not evidence of a wasted preload.
            if (show != null && load.format in setOf("interstitial", "rewarded", "app_open") &&
                reason in setOf("replaced", "load_failure_clear")) return
            if (!once("discard:$loadId")) return
            emit("ads_ad_discarded", envelope(load.format, show?.opportunityId ?: load.opportunityId) + mapOf(
                "load_attempt_id" to load.id, "reason" to reason,
                "cache_age_ms" to (nowMs() - load.completedAt!!).coerceAtLeast(0),
            ) + unit(load.adUnitId))
        }
    }

    private val seen = LinkedHashMap<String, Long>()
    private fun once(key: String): Boolean {
        if (seen.containsKey(key)) return false
        seen[key] = nowMs()
        while (seen.size > maxEntries) seen.remove(seen.keys.first())
        return true
    }

    private fun prune() {
        val cutoff = nowMs() - retentionMs
        var dropped = 0
        fun <T> trim(map: LinkedHashMap<String, T>, time: (T) -> Long) {
            val iterator = map.entries.iterator()
            while (iterator.hasNext()) {
                val entry = iterator.next()
                if (time(entry.value) < cutoff || map.size >= maxEntries) {
                    iterator.remove()
                    dropped++
                }
            }
        }
        trim(opportunities) { it.openedAt }
        trim(loads) { it.startedAt }
        trim(shows) { it.startedAt }
        seen.entries.removeAll { it.value < cutoff }
        openLoads.values.forEach { queue -> queue.removeAll { it !in loads } }
        openShows.values.forEach { queue -> queue.removeAll { it !in shows } }
        readyLoad.entries.removeAll { it.value !in loads }
        slotOpportunity.entries.removeAll { it.value !in opportunities }
        if (dropped > 0) onDrop(dropped)
    }

    private fun pollLoad(format: String): Attempt? {
        val id = openLoads[format]?.pollFirst() ?: return null
        return loads[id]
    }

    private fun pollShow(format: String): Attempt? {
        val id = openShows[format]?.pollFirst() ?: return null
        return shows[id]
    }

    private fun envelope(format: String, opportunityId: String?): Map<String, Any> {
        val params = LinkedHashMap<String, Any>()
        params["event_id"] = nextId("e")
        params["schema_version"] = 1L
        params["mediation"] = mediation().ifBlank { "unresolved" }
        params["format"] = format
        params["sdk_version"] = sdkVersion
        if (opportunityId != null) {
            params["opportunity_id"] = opportunityId
            opportunities[opportunityId]?.let { opp ->
                params["placement"] = opp.placement
                params["opportunity_scope"] = opp.scope
            }
        }
        return params
    }

    private fun unit(adUnitId: String?): Map<String, Any> =
        if (adUnitId.isNullOrBlank()) emptyMap() else mapOf("ad_unit_id" to adUnitId)

    private fun source(adSource: String?): Map<String, Any> =
        if (adSource.isNullOrBlank()) emptyMap() else mapOf("ad_source" to adSource)

    private fun nextId(prefix: String): String = processId + "-" + prefix + seq.incrementAndGet().toString(36)

    private class Opp(
        val id: String,
        val placement: String,
        val format: String,
        val trigger: String,
        val scope: String,
        val openedAt: Long,
        var cacheState: String = "not_checked",
        var cacheLocked: Boolean = false,
        var ended: Boolean = false,
        var released: Boolean = false,
        var outcome: String? = null,
        var adUnitId: String? = null,
    )

    private class Attempt(
        val id: String,
        val format: String,
        val opportunityId: String?,
        val startedAt: Long,
        val adUnitId: String?,
        val mode: String,
        val retryIndex: Int,
        val loadAttemptId: String? = null,
        var done: Boolean = false,
        var completedAt: Long? = null,
        var impressed: Boolean = false,
    )

    private companion object {
        const val SCOPE_PRODUCT = "product"
        const val SCOPE_SDK_ENTRY = "sdk_entry"
        const val PLACEMENT_UNKNOWN = "unknown"
        const val OUTCOME_IMPRESSION = "impression"
        const val OUTCOME_SKIPPED = "skipped"
        const val OUTCOME_FAILED = "failed"
        const val OUTCOME_ABANDONED = "abandoned"
        const val STAGE_GATE = "gate"
        const val STAGE_SHOW = "show"
        const val STAGE_IMPRESSION = "impression"
    }
}
