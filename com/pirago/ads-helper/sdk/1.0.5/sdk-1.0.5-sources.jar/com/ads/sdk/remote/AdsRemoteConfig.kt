package com.ads.sdk.remote

import android.os.Handler
import android.os.Looper
import com.ads.sdk.AdsConfig
import com.ads.sdk.Mediation
import com.ads.sdk.OpenAdFormat
import com.ads.sdk.RemoteConfigPolicy
import com.ads.sdk.internal.SdkLog
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Firebase Remote Config is fetched as **one template**, then read by key.
 * There is no API to fetch a single key from the server.
 *
 * [RemoteConfigPolicy.FetchAndRead] starts in [com.ads.sdk.AdsSdk.init] (Application.onCreate).
 * A launch that already has an activated template does not wait. The first launch waits at most
 * [REMOTE_FETCH_TIMEOUT_SEC] seconds, then continues with safe defaults.
 */
class AdsRemoteConfig internal constructor(
    private val config: AdsConfig,
) {
    /**
     * True when this process has no activated remote template (first launch timeout/failure,
     * or a later launch that still has never activated). Open and resume stay off.
     * Mediation and intervals use [AdsConfig].
     */
    @Volatile
    internal var usingSafeDefaults: Boolean = false
        private set

    @Volatile
    internal var isBootstrapDone: Boolean = false
        private set

    private val readyLock = Any()
    private val readyWaiters = mutableListOf<() -> Unit>()

    fun applyAsync(onReady: () -> Unit) {
        when (config.remote) {
            RemoteConfigPolicy.None -> onReady()
            RemoteConfigPolicy.ReadOnly -> onReady()
            RemoteConfigPolicy.FetchAndRead -> load(onReady)
        }
    }

    internal fun whenReady(block: () -> Unit) {
        if (config.remote != RemoteConfigPolicy.FetchAndRead) {
            block()
            return
        }
        val runNow = synchronized(readyLock) {
            if (isBootstrapDone) {
                true
            } else {
                readyWaiters.add(block)
                false
            }
        }
        if (runNow) block()
    }

    internal fun markReady() {
        val waiters = synchronized(readyLock) {
            if (isBootstrapDone) return
            isBootstrapDone = true
            readyWaiters.toList().also { readyWaiters.clear() }
        }
        waiters.forEach { waiter ->
            runCatching { waiter() }.onFailure { error ->
                SdkLog.w("RemoteConfig waiter failed", error)
            }
        }
    }

    /**
     * Pulls the full RC template then activates it. Does not gate [com.ads.sdk.AdsSdk.init].
     * Call [getBoolean]/[getLong]/[getString] after this.
     */
    fun fetch(onComplete: (success: Boolean) -> Unit = {}) {
        val rc = firebaseOrNull()
        if (rc == null) {
            SdkLog.w("RemoteConfig: Firebase not initialized (add google-services.json)")
            onComplete(false)
            return
        }
        rc.fetchAndActivate().addOnCompleteListener { task ->
            if (!task.isSuccessful) {
                SdkLog.w("RemoteConfig fetch failed", task.exception)
            }
            onComplete(task.isSuccessful)
        }
    }

    fun setDefaults(values: Map<String, Any>) {
        firebaseOrNull()?.setDefaultsAsync(values)
    }

    fun getBoolean(key: String, default: Boolean = false): Boolean {
        val value = valueOrNull(key) ?: return default
        return runCatching { value.asBoolean() }.getOrDefault(default)
    }

    fun getLong(key: String, default: Long = 0L): Long {
        val value = valueOrNull(key) ?: return default
        return runCatching { value.asLong() }.getOrDefault(default)
    }

    fun getDouble(key: String, default: Double = 0.0): Double {
        val value = valueOrNull(key) ?: return default
        return runCatching { value.asDouble() }.getOrDefault(default)
    }

    fun getString(key: String, default: String = ""): String {
        val value = valueOrNull(key) ?: return default
        return runCatching { value.asString() }.getOrDefault(default)
    }

    fun interstitialIntervalSec(): Int {
        if (usingSafeDefaults) return config.interstitialIntervalSec.coerceAtLeast(0)
        val key = config.interstitialIntervalRemoteKey
        val fromRc = if (key.isNullOrBlank()) {
            config.interstitialIntervalSec.toLong()
        } else {
            getLong(key, config.interstitialIntervalSec.toLong())
        }
        return fromRc.toInt().coerceAtLeast(0)
    }

    fun resumeAdsIntervalSec(): Int {
        if (usingSafeDefaults) return config.resumeAdsIntervalSec.coerceAtLeast(0)
        val key = config.resumeAdsIntervalRemoteKey
        val fromRc = if (key.isNullOrBlank()) {
            config.resumeAdsIntervalSec.toLong()
        } else {
            getLong(key, config.resumeAdsIntervalSec.toLong())
        }
        return fromRc.toInt().coerceAtLeast(0)
    }

    fun mediationType(): Mediation {
        if (usingSafeDefaults) return Mediation.fromRemote(config.mediationDefault)
        val key = config.mediationRemoteKey
        val raw = if (key.isNullOrBlank()) {
            config.mediationDefault
        } else {
            mediationRaw(key, config.mediationDefault)
        }
        return Mediation.fromRemote(raw)
    }

    fun openAdFormat(key: String?, default: OpenAdFormat): OpenAdFormat {
        if (key.isNullOrBlank()) return default
        val value = valueOrNull(key) ?: return default
        val asString = runCatching { value.asString() }.getOrNull()
        return OpenAdFormat.parse(asString, default)
    }

    private fun load(onReady: () -> Unit) {
        val rc = firebaseOrNull()
        if (rc == null) {
            SdkLog.w("RemoteConfig: Firebase not initialized (add google-services.json)")
            usingSafeDefaults = true
            onReady()
            return
        }
        val once = AtomicBoolean(false)
        val handler = Handler(Looper.getMainLooper())
        val hasRemote = runCatching { hasActivatedRemote(rc) }.getOrDefault(false)
        val neverFetched = runCatching {
            rc.info.lastFetchStatus == FirebaseRemoteConfig.LAST_FETCH_STATUS_NO_FETCH_YET
        }.getOrDefault(true)
        val settings = FirebaseRemoteConfigSettings.Builder()
            .setFetchTimeoutInSeconds(REMOTE_FETCH_TIMEOUT_SEC)
            .setMinimumFetchIntervalInSeconds(if (config.debug) 0 else 3600)
            .build()
        rc.setConfigSettingsAsync(settings)
        rc.setDefaultsAsync(config.firebaseDefaults())

        fun deliver(safe: Boolean) {
            if (!once.compareAndSet(false, true)) return
            handler.removeCallbacksAndMessages(null)
            usingSafeDefaults = safe
            if (safe) {
                SdkLog.w("RemoteConfig unavailable; safe defaults (AdMob, no open/resume)")
            }
            onReady()
        }

        if (!shouldWaitForFirstRemoteFetch(neverFetched, hasRemote)) {
            handler.postDelayed({ deliver(!hasActivatedRemote(rc)) }, REMOTE_FETCH_TIMEOUT_SEC * 1000L)
            rc.activate().addOnCompleteListener {
                val safe = !hasActivatedRemote(rc)
                deliver(safe)
                rc.fetch()
            }
            return
        }

        handler.postDelayed({ deliver(true) }, REMOTE_FETCH_TIMEOUT_SEC * 1000L)
        rc.setConfigSettingsAsync(settings)
            .continueWithTask { rc.setDefaultsAsync(config.firebaseDefaults()) }
            .addOnCompleteListener {
                if (once.get()) return@addOnCompleteListener
                rc.fetch().addOnCompleteListener { task ->
                    if (!task.isSuccessful) {
                        SdkLog.w("RemoteConfig fetch failed", task.exception)
                        deliver(true)
                        return@addOnCompleteListener
                    }
                    if (!once.compareAndSet(false, true)) return@addOnCompleteListener
                    handler.removeCallbacksAndMessages(null)
                    rc.activate().addOnCompleteListener {
                        usingSafeDefaults = false
                        onReady()
                    }
                }
            }
    }

    private fun hasActivatedRemote(rc: FirebaseRemoteConfig): Boolean {
        val keys = listOfNotNull(
            config.mediationRemoteKey,
            config.interstitialIntervalRemoteKey,
            config.resumeAdsIntervalRemoteKey,
            config.resumeRemoteKey,
            config.resumeTypeRemoteKey,
            config.openAds.formatRemoteKey,
            config.openAds.enabledRemoteKey,
            config.openAds.firstOpenRemoteKey,
            config.openAds.typeIsInterRemoteKey,
        ).filter { it.isNotBlank() }
        return keys.any { key ->
            rc.getValue(key).source == FirebaseRemoteConfig.VALUE_SOURCE_REMOTE
        }
    }

    private fun mediationRaw(key: String, default: Int): Int {
        val value = valueOrNull(key) ?: return default
        runCatching { value.asLong().toInt() }.getOrNull()?.let { return it }
        val asString = runCatching { value.asString() }.getOrNull()?.trim().orEmpty()
        if (asString.isNotEmpty()) {
            asString.toDoubleOrNull()?.toInt()?.let { return it }
        }
        return default
    }

    private fun valueOrNull(key: String) = firebaseOrNull()?.getValue(key)?.takeIf {
        it.source != FirebaseRemoteConfig.VALUE_SOURCE_STATIC
    }

    private fun firebaseOrNull(): FirebaseRemoteConfig? {
        return runCatching { FirebaseRemoteConfig.getInstance() }.getOrNull()
    }
}
