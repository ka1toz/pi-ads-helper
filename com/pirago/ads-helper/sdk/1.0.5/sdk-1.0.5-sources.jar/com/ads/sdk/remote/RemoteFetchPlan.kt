package com.ads.sdk.remote

import com.ads.sdk.AdsConfig
import com.ads.sdk.OpenAdFormat

/** Splash must not wait on Firebase's 60s fetch timeout. */
internal const val REMOTE_FETCH_TIMEOUT_SEC = 5L

/**
 * Wait for the network only on the first attempt. A later launch uses the last
 * activated template, or safe defaults, and refreshes in the background.
 */
internal fun shouldWaitForFirstRemoteFetch(neverFetched: Boolean, hasActivatedRemote: Boolean): Boolean {
    return neverFetched && !hasActivatedRemote
}

internal fun OpenAdFormat.toRemoteString(): String = when (this) {
    OpenAdFormat.Off -> ""
    OpenAdFormat.Inter -> "inter"
    OpenAdFormat.AppOpen -> "aoa"
}

/** In-app defaults so a successful fetch that omits a key still has a value. */
internal fun AdsConfig.firebaseDefaults(): Map<String, Any> {
    val values = linkedMapOf<String, Any>()
    fun put(key: String?, value: Any) {
        if (!key.isNullOrBlank()) values[key] = value
    }
    put(mediationRemoteKey, mediationDefault.toLong())
    put(interstitialIntervalRemoteKey, interstitialIntervalSec.toLong())
    put(resumeAdsIntervalRemoteKey, resumeAdsIntervalSec.toLong())
    put(resumeRemoteKey, enableResumeAds)
    put(resumeTypeRemoteKey, resumeTypeDefault.toRemoteString())
    put(openAds.formatRemoteKey, openAds.formatDefault.toRemoteString())
    put(openAds.enabledRemoteKey, openAds.enabledDefault)
    put(openAds.firstOpenRemoteKey, openAds.firstOpenDefault)
    put(openAds.typeIsInterRemoteKey, openAds.typeIsInterDefault)
    return values
}
