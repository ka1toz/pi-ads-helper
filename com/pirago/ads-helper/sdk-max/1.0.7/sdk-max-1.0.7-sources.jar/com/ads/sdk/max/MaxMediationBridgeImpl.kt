package com.ads.sdk.max

import android.app.Activity
import android.app.Application
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.ads.sdk.AdsSdk
import com.ads.sdk.BannerConfig
import com.ads.sdk.BannerType
import com.ads.sdk.PaidAdEvent
import com.ads.sdk.R
import com.ads.sdk.callback.AdCallback
import com.ads.sdk.callback.AdError
import com.ads.sdk.mediation.MaxMediationBridge
import com.applovin.mediation.MaxAd
import com.applovin.mediation.MaxAdFormat
import com.applovin.mediation.MaxAdListener
import com.applovin.mediation.MaxAdRevenueListener
import com.applovin.mediation.MaxAdViewAdListener
import com.applovin.mediation.MaxErrorCode
import com.applovin.mediation.MaxError
import com.applovin.mediation.ads.MaxAdView
import com.applovin.mediation.ads.MaxAppOpenAd
import com.applovin.mediation.ads.MaxInterstitialAd
import com.applovin.sdk.AppLovinMediationProvider
import com.applovin.sdk.AppLovinSdk
import com.applovin.sdk.AppLovinSdkInitializationConfiguration
import com.applovin.sdk.AppLovinSdkUtils
import kotlin.math.pow

/**
 * Public no-arg constructor — loaded from `:ads-sdk` via reflection.
 */
class MaxMediationBridgeImpl : MaxMediationBridge {

    private val handler = Handler(Looper.getMainLooper())
    private val cycles = com.ads.sdk.internal.LoadCycles<Any>()
    private val pendingLoads = java.util.WeakHashMap<Any, MutableList<String>>()
    private val adLoads = java.util.WeakHashMap<Any, String>()
    private val paidAds = java.util.WeakHashMap<MaxAd, Boolean>()
    private val revenueShows = java.util.WeakHashMap<MaxAd, String>()
    private var loadedInterstitialAd: MaxAd? = null
    private var loadedAppOpenAd: MaxAd? = null

    private fun beginLoad(ad: Any, format: String, unit: String, retry: Int, mode: String = "preload", opportunityId: String? = null) {
        val cycle = if (retry == 0) cycles.start(ad, mode, opportunityId) else cycles.get(ad) ?: return
        val id = AdsSdk.notePlatformLoad(format, unit, retry, cycle.mode, cycle.opportunityId) ?: return
        val pending = pendingLoads.getOrPut(ad) { mutableListOf() }
        // Two IDs are enough to mark ambiguity; do not accumulate an unbounded list.
        if (pending.size < 2) pending.add(id)
    }

    private fun finishLoad(ad: Any, format: String, success: Boolean, code: String?): String? {
        val ids = pendingLoads.remove(ad) ?: return null
        if (ids.size == 1) {
            AdsSdk.notePlatformLoadResult(format, success, code, ids.single(), failureReason(code))
            return ids.single()
        } else {
            // MAX callbacks do not contain our request ID. Do not guess FIFO for overlapping calls.
            Log.w(TAG, "Trace result unlinked: overlapping $format loads on one ad instance")
            return null
        }
    }

    @Volatile private var interstitial: MaxInterstitialAd? = null
    @Volatile private var interstitialUnitId: String? = null
    @Volatile private var interstitialCallback: AdCallback? = null
    @Volatile private var interstitialClosed: (() -> Unit)? = null
    private var interstitialRetry = 0

    @Volatile private var appOpen: MaxAppOpenAd? = null
    @Volatile private var appOpenCallback: AdCallback? = null
    private var appOpenRetry = 0

    override fun initialize(
        application: Application,
        sdkKey: String,
        testDeviceAdvertisingIds: List<String>,
        onComplete: () -> Unit,
    ) {
        val builder = AppLovinSdkInitializationConfiguration.builder(sdkKey, application)
            .setMediationProvider(AppLovinMediationProvider.MAX)
        if (testDeviceAdvertisingIds.isNotEmpty()) {
            builder.setTestDeviceAdvertisingIds(testDeviceAdvertisingIds)
        }
        AppLovinSdk.getInstance(application).initialize(builder.build()) {
            Log.d(TAG, "AppLovin MAX initialized")
            onComplete()
        }
    }

    override fun showMediationDebugger(activity: Activity) {
        handler.post {
            AppLovinSdk.getInstance(activity).showMediationDebugger()
        }
    }

    override fun loadBanner(
        activity: Activity,
        container: ViewGroup,
        shimmer: View?,
        config: BannerConfig,
        callback: AdCallback?,
        opportunityId: String?,
    ) {
        destroyBanner(container)
        shimmer?.visibility = View.VISIBLE
        val adView = MaxAdView(config.adUnitId, activity)
        adView.setExtraParameter("adaptive_banner", "true")
        val heightDp = when (config.type) {
            BannerType.Large -> 90
            BannerType.Standard -> 50
            else -> 50
        }
        val heightPx = AppLovinSdkUtils.dpToPx(activity, heightDp)
        adView.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            heightPx,
        )
        container.addView(adView)
        container.setTag(R.id.ads_sdk_max_ad_view, adView)
        bindViewListener(adView, config.adUnitId, "banner", shimmer, callback, opportunityId)
        adView.loadAd()
    }

    override fun hideBanner(container: ViewGroup) {
        (container.getTag(R.id.ads_sdk_max_ad_view) as? MaxAdView)?.visibility = View.GONE
        container.visibility = View.GONE
    }

    override fun destroyBanner(container: ViewGroup) {
        val adView = container.getTag(R.id.ads_sdk_max_ad_view) as? MaxAdView
        adView?.let { AdsSdk.notePlatformDiscard(adLoads[it], "slot_removed") }
        adView?.destroy()
        container.setTag(R.id.ads_sdk_max_ad_view, null)
        if (adView != null) container.removeView(adView)
    }

    override fun loadMrec(
        activity: Activity,
        container: ViewGroup,
        adUnitId: String,
        shimmer: View?,
        callback: AdCallback?,
        opportunityId: String?,
    ) {
        destroyMrec(container)
        shimmer?.visibility = View.VISIBLE
        val adView = MaxAdView(adUnitId, MaxAdFormat.MREC, activity)
        val widthPx = AppLovinSdkUtils.dpToPx(activity, 300)
        val heightPx = AppLovinSdkUtils.dpToPx(activity, 250)
        adView.layoutParams = FrameLayout.LayoutParams(widthPx, heightPx)
        container.addView(adView)
        container.setTag(R.id.ads_sdk_mrec_view, adView)
        bindViewListener(adView, adUnitId, "mrec", shimmer, callback, opportunityId)
        adView.loadAd()
    }

    override fun destroyMrec(container: ViewGroup) {
        val adView = container.getTag(R.id.ads_sdk_mrec_view) as? MaxAdView
        adView?.let { AdsSdk.notePlatformDiscard(adLoads[it], "slot_removed") }
        adView?.destroy()
        container.setTag(R.id.ads_sdk_mrec_view, null)
        if (adView != null) container.removeView(adView)
    }

    override fun loadInterstitial(activity: Activity, adUnitId: String, callback: AdCallback?, loadMode: String, opportunityId: String?) {
        interstitialCallback = callback
        val existing = interstitial
        if (existing != null && interstitialUnitId == adUnitId) {
            if (existing.isReady) {
                callback?.onAdLoaded()
                return
            }
            beginLoad(existing, "interstitial", adUnitId, 0, loadMode, opportunityId)
            existing.loadAd()
            return
        }
        loadedInterstitialAd?.let { AdsSdk.notePlatformDiscard(adLoads[it], "replaced") }
        existing?.setListener(null)
        val ad = MaxInterstitialAd(adUnitId, activity)
        interstitial = ad
        interstitialUnitId = adUnitId
        interstitialRetry = 0
        ad.setRevenueListener { maxAd -> pay(maxAd, "interstitial", adUnitId, revenueShows[maxAd], linked = revenueShows.containsKey(maxAd)) }
        beginLoad(ad, "interstitial", adUnitId, 0, loadMode, opportunityId)
        ad.setListener(object : MaxAdListener {
            override fun onAdLoaded(maxAd: MaxAd) {
                interstitialRetry = 0
                loadedInterstitialAd?.let { AdsSdk.notePlatformDiscard(adLoads[it], "replaced") }
                loadedInterstitialAd = maxAd
                finishLoad(ad, "interstitial", true, null)?.let { adLoads[maxAd] = it }
                interstitialCallback?.onAdLoaded()
            }

            override fun onAdLoadFailed(unitId: String, error: MaxError) {
                finishLoad(ad, "interstitial", false, error.code.toString())
                interstitialCallback?.onAdFailedToLoad(AdError(error.code, error.message))
                retryInterstitial(ad)
            }

            override fun onAdDisplayed(maxAd: MaxAd) {
                interstitialCallback?.onAdShown()
                interstitialCallback?.onAdImpression()
            }

            override fun onAdHidden(maxAd: MaxAd) {
                AdsSdk.notePlatformLifecycle("ads_dismiss", "interstitial", revenueShows[maxAd])
                val closed = interstitialClosed
                interstitialClosed = null
                closed?.invoke()
                beginLoad(ad, "interstitial", ad.adUnitId, 0)
                ad.loadAd()
            }

            override fun onAdClicked(maxAd: MaxAd) {
                AdsSdk.notePlatformLifecycle("ads_click", "interstitial", revenueShows[maxAd])
                interstitialCallback?.onAdClicked()
            }

            override fun onAdDisplayFailed(maxAd: MaxAd, error: MaxError) {
                interstitialCallback?.onAdFailedToLoad(AdError(error.code, error.message))
                val closed = interstitialClosed
                interstitialClosed = null
                closed?.invoke()
                beginLoad(ad, "interstitial", ad.adUnitId, 0)
                ad.loadAd()
            }
        })
        ad.loadAd()
    }

    override fun isInterstitialReady(): Boolean = interstitial?.isReady == true

    override fun showInterstitial(activity: Activity, callback: AdCallback, showAttemptId: String?, onClosed: () -> Unit) {
        val ad = interstitial
        if (ad == null || !ad.isReady) {
            callback.onAdFailedToLoad(AdError(message = "max interstitial not ready"))
            onClosed()
            return
        }
        interstitialCallback = callback
        interstitialClosed = onClosed
        loadedInterstitialAd?.let { if (showAttemptId != null) revenueShows[it] = showAttemptId }
        ad.showAd()
    }

    override fun loadAppOpen(activity: Activity, adUnitId: String, callback: AdCallback?, loadMode: String, opportunityId: String?) {
        appOpenCallback = callback
        val existing = appOpen
        if (existing != null) {
            if (existing.isReady) {
                callback?.onAdLoaded()
                return
            }
            beginLoad(existing, "app_open", adUnitId, 0, loadMode, opportunityId)
            existing.loadAd()
            return
        }
        val ad = MaxAppOpenAd(adUnitId, activity)
        appOpen = ad
        appOpenRetry = 0
        ad.setRevenueListener { maxAd -> pay(maxAd, "app_open", adUnitId, revenueShows[maxAd], linked = revenueShows.containsKey(maxAd)) }
        beginLoad(ad, "app_open", adUnitId, 0, loadMode, opportunityId)
        ad.setListener(object : MaxAdListener {
            override fun onAdLoaded(maxAd: MaxAd) {
                appOpenRetry = 0
                loadedAppOpenAd?.let { AdsSdk.notePlatformDiscard(adLoads[it], "replaced") }
                loadedAppOpenAd = maxAd
                finishLoad(ad, "app_open", true, null)?.let { adLoads[maxAd] = it }
                appOpenCallback?.onAdLoaded()
            }

            override fun onAdLoadFailed(unitId: String, error: MaxError) {
                finishLoad(ad, "app_open", false, error.code.toString())
                appOpenCallback?.onAdFailedToLoad(AdError(error.code, error.message))
                retryAppOpen(ad)
            }

            override fun onAdDisplayed(maxAd: MaxAd) {
                appOpenCallback?.onAdShown()
                appOpenCallback?.onAdImpression()
            }

            override fun onAdHidden(maxAd: MaxAd) {
                AdsSdk.notePlatformLifecycle("ads_dismiss", "app_open", revenueShows[maxAd])
                val cb = appOpenCallback
                appOpenCallback = null
                cb?.onAdDismissed()
                cb?.onNextAction()
                beginLoad(ad, "app_open", ad.adUnitId, 0)
                ad.loadAd()
            }

            override fun onAdClicked(maxAd: MaxAd) {
                AdsSdk.notePlatformLifecycle("ads_click", "app_open", revenueShows[maxAd])
                appOpenCallback?.onAdClicked()
            }

            override fun onAdDisplayFailed(maxAd: MaxAd, error: MaxError) {
                val cb = appOpenCallback
                appOpenCallback = null
                cb?.onAdFailedToLoad(AdError(error.code, error.message))
                cb?.onNextAction()
                beginLoad(ad, "app_open", ad.adUnitId, 0)
                ad.loadAd()
            }
        })
        ad.loadAd()
    }

    override fun isAppOpenReady(): Boolean = appOpen?.isReady == true

    override fun showAppOpen(activity: Activity, callback: AdCallback, showAttemptId: String?) {
        val ad = appOpen
        if (ad == null || !ad.isReady) {
            callback.onAdFailedToLoad(AdError(message = "max app open not ready"))
            callback.onNextAction()
            return
        }
        appOpenCallback = callback
        loadedAppOpenAd?.let { if (showAttemptId != null) revenueShows[it] = showAttemptId }
        ad.showAd()
    }

    private fun bindViewListener(
        adView: MaxAdView,
        adUnitId: String,
        format: String,
        shimmer: View?,
        callback: AdCallback?,
        opportunityId: String?,
    ) {
        val loadId = AdsSdk.notePlatformViewLoad(format, adUnitId, opportunityId)
        adLoads[adView] = loadId
        val showId = AdsSdk.notePlatformViewAttached(format, opportunityId, loadId)
        var firstLoadResult = true
        var linkedImpression = true
        adView.setRevenueListener { maxAd ->
            pay(maxAd, format, adUnitId, showId, opportunityId, linkedImpression)
        }
        adView.setListener(object : MaxAdViewAdListener {
            override fun onAdLoaded(maxAd: MaxAd) {
                shimmer?.visibility = View.GONE
                linkedImpression = firstLoadResult
                if (firstLoadResult) {
                    AdsSdk.notePlatformLoadResult(format, true, null, loadId)
                    firstLoadResult = false
                }
                callback?.onAdLoaded()
            }

            override fun onAdLoadFailed(unitId: String, error: MaxError) {
                shimmer?.visibility = View.GONE
                if (firstLoadResult) {
                    AdsSdk.notePlatformLoadResult(format, false, error.code.toString(), loadId, failureReason(error.code.toString()))
                    firstLoadResult = false
                }
                callback?.onAdFailedToLoad(AdError(error.code, error.message))
            }

            override fun onAdDisplayed(maxAd: MaxAd) {
                callback?.onAdShown()
                callback?.onAdImpression()
            }

            override fun onAdHidden(maxAd: MaxAd) = Unit
            override fun onAdClicked(maxAd: MaxAd) {
                AdsSdk.notePlatformLifecycle("ads_click", format, if (linkedImpression) showId else null, opportunityId)
                callback?.onAdClicked()
            }

            override fun onAdDisplayFailed(maxAd: MaxAd, error: MaxError) {
                callback?.onAdFailedToLoad(AdError(error.code, error.message))
            }

            override fun onAdExpanded(maxAd: MaxAd) = Unit
            override fun onAdCollapsed(maxAd: MaxAd) = Unit
        })
    }

    private fun retryInterstitial(ad: MaxInterstitialAd) {
        val cycle = cycles.get(ad) ?: return
        val retryIndex = interstitialRetry + 1
        val delay = retryDelayMs(interstitialRetry++)
        handler.postDelayed({
            if (interstitial === ad && cycles.current(ad, cycle)) {
                beginLoad(ad, "interstitial", ad.adUnitId, retryIndex)
                ad.loadAd()
            }
        }, delay)
    }

    private fun retryAppOpen(ad: MaxAppOpenAd) {
        val cycle = cycles.get(ad) ?: return
        val retryIndex = appOpenRetry + 1
        val delay = retryDelayMs(appOpenRetry++)
        handler.postDelayed({
            if (appOpen === ad && cycles.current(ad, cycle)) {
                beginLoad(ad, "app_open", ad.adUnitId, retryIndex)
                ad.loadAd()
            }
        }, delay)
    }

    private fun failureReason(code: String?): String = when (code?.toIntOrNull()) {
        MaxErrorCode.NO_FILL -> "no_fill"
        MaxErrorCode.NO_NETWORK, MaxErrorCode.NETWORK_ERROR -> "network_error"
        MaxErrorCode.NETWORK_TIMEOUT -> "network_timeout"
        MaxErrorCode.INVALID_AD_UNIT_ID -> "invalid_request"
        else -> "load_error"
    }

    private fun retryDelayMs(attempt: Int): Long {
        val capped = attempt.coerceAtMost(6)
        return (2.0.pow(capped) * 1000L).toLong().coerceAtMost(64_000L)
    }

    private fun pay(
        ad: MaxAd, format: String, fallbackUnit: String,
        showAttemptId: String? = null, opportunityId: String? = null, linked: Boolean = true,
    ) {
        if (synchronized(paidAds) { paidAds.put(ad, true) != null }) return
        AdsSdk.notePlatformImpression(format, ad.networkName, showAttemptId, opportunityId, linked)
        val priced = PaidAdEvent.fromMax(
            revenueUsd = ad.revenue,
            networkName = ad.networkName,
            adFormat = format,
            adUnitId = ad.adUnitId.ifBlank { fallbackUnit },
        )
        if (priced.isBillable()) AdsSdk.notifyPaid(AdsSdk.platformPaidContext(priced, showAttemptId, opportunityId, linked))
    }

    private companion object {
        const val TAG = "AdsSdk.MAX"
    }
}
